assayDataNew <- function(storage.mode = c("lockedEnvironment", "environment", "list"), ...) {
  storage.mode <- match.arg(storage.mode) # defaults to "lockedEnvironment"
  assayData <- switch(storage.mode,
                      lockedEnvironment =,
                      environment = new.env(parent=emptyenv()),
                      list = list())
  arglist <- list(...)
  for (nm in names(arglist)) assayData[[nm]] <- arglist[[nm]]
  if (storage.mode == "lockedEnvironment") assayDataEnvLock(assayData)
  msg <- assayDataValidMembers(assayData)
  if (!is.logical(msg)) stop(msg)
  assayData
}

assayDataValidMembers <- function(assayData, required) {
    msg <- NULL
    eltNames <-
      if ("list" == assayDataStorageMode(assayData)) names(assayData)
      else ls(assayData)
    if (!missing(required)) {
        absent <- required[!required %in% eltNames]
        if (length(absent) != 0)
          msg <- paste(msg, 
                       paste("'AssayData' missing '", absent ,"'" , sep = "", collapse = "\n\t"),
                       sep="\n")
    }
    dimsOk <-
      sapply(eltNames, function(elt)
             tryCatch(length(dim(assayData[[elt]]))>1,
                      error=function(err) FALSE))
    if (!all(dimsOk)) 
      msg <- c(msg, paste("'AssayData' elements with invalid dimensions: '",
                          paste(eltNames[!dimsOk], collapse="' '"), "'", sep=""))
    if (length(assayData)>1) {
        eltRowNames <- rownames(assayData[[eltNames[[1]]]])
        rowNamesOk <- 
          all(sapply(eltNames[-1], function(elt)
                     all(eltRowNames == rownames(assayData[[elt]]))))
        if (!rowNamesOk)
          msg <- c(msg, "'AssayData' elements with different rowNames")
    }
    if (is.null(msg)) TRUE else msg
}

assayDataStorageMode <- function(object) {
  if (is(object, "list"))
    "list"
  else if (environmentIsLocked(object))
    "lockedEnvironment"
  else
    "environment"
}

setMethod("storageMode", "AssayData", assayDataStorageMode)

assayDataStorageModeReplace <- function(object, value) {
    storageMode <- assayDataStorageMode(object)
    if (storageMode == value) return(object)
    names <- if (storageMode == "list") names(object) else ls(object)
    switch(value,
           lockedEnvironment = {
               assayData <- new.env(parent=emptyenv())
               for (nm in names) assayData[[nm]] <- object[[nm]]
               assayDataEnvLock(assayData)
               assayData
           }, environment = {
               assayData <- new.env(parent=emptyenv())
               for (nm in names) assayData[[nm]] <- object[[nm]]
               assayData
           }, list = as.list(object))
}

setReplaceMethod("storageMode",
                 signature=c(object="AssayData", value="character"),
                 assayDataStorageModeReplace)

assayDataEnvLock <- function(assayData)
  lockEnvironment(assayData, bindings=TRUE)

assayDataSubsetElements <-
  function(object, elts, storageMode = assayDataStorageMode(object)) {
    if (any(duplicated(elts)))
      stop("'AssayData' element names must be unique")
    names <-
        if (storageMode(object)=="list") names(object)
        else ls(object)
    if (!all(elts %in% names))
      stop("'AssayData' missing elements: '",
           paste(elts[!elts %in% names], collapse="', '", sep=""), "'")
    switch(storageMode,
           lockedEnvironment = {
               assayData <- new.env(parent = emptyenv())
               for (nm in elts) assayData[[nm]] <- object[[nm]]
               assayDataEnvLock(assayData)
               assayData
           },
           environment = {
               assayData <- new.env(parent = emptyenv())
               for (nm in elts) assayData[[nm]] <- object[[nm]]
               assayData
           },
           list = {
               object[elts]
           })
}

setMethod("assayData",
          signature=signature(object="AssayData"),
          function(object) object)

.assayDataDimnames <- function(assayData) {
    switch(storageMode(assayData),
           lockedEnvironment=,
           environment=eapply(assayData, dimnames),
           list=lapply(assayData, dimnames))
}

setMethod("sampleNames", signature(object="AssayData"),
          function(object) {
              if (!length(object))
                return(character(0))
              switch(assayDataStorageMode(object),
                     list=colnames(object[[1]]),
                     colnames(object[[ls(object)[1]]]))
          })

setReplaceMethod("sampleNames", c("AssayData", "ANY"), function(object, value) {
    dims <- 
      switch(assayDataStorageMode(object),
             lockedEnvironment=,
             environment = eapply(object, ncol),
             list = lapply(object, ncol))
    if (length(dims)==0 && length(value) !=0)
      return(object)                    # early exit; no samples to name
    if (!all(dims==length(value)))
      stop("'value' length (", length(value),
           ") must equal sample number in AssayData (",dims[[1]], ")")
    switch(assayDataStorageMode(object),
           lockedEnvironment = {
               object <- copyEnv(object)
               for (nm in ls(object)) colnames(object[[nm]]) <- value
               assayDataEnvLock(object)
           },
           environment = for (nm in ls(object)) colnames(object[[nm]]) <- value,
           list = for (nm in names(object)) colnames(object[[nm]]) <- value
           )
    object
})

setReplaceMethod("sampleNames",
                 signature=signature(
                   object="AssayData",
                   value="list"),
                 function(object, value) {
                     switch(assayDataStorageMode(object),
                            lockedEnvironment = {
                                object <- copyEnv(object)
                                for (nm in names(value))
                                  colnames(object[[nm]]) <- value[[nm]]
                                assayDataEnvLock(object)
                            }, environment = {
                                for (nm in names(value))
                                  colnames(object[[nm]]) <- value[[nm]]
                            }, list= {
                                for (nm in names(value))
                                  colnames(object[[nm]]) <- value[[nm]]
                            })
                     object
                 })

setMethod("featureNames", signature(object="AssayData"),
          function(object) {
              if (!length(object))
                return(character(0))
              switch(assayDataStorageMode(object),
                     list=rownames(object[[1]]),
                     rownames(object[[ls(object)[1]]]))
          })


setReplaceMethod("featureNames", signature(object="AssayData", value="ANY"),
                 function(object, value) {
    dims <- 
      switch(assayDataStorageMode(object),
             lockedEnvironment=,
             environment = eapply(object, nrow),
             list = lapply(object, nrow))
    if (length(dims)==0 && length(value) !=0)
      return(object)                    # early exit; no features to name
    if (!all(dims==length(value)))
      stop("'value' length (", length(value),
           ") must equal feature number in AssayData (",dims[[1]], ")")
    switch(assayDataStorageMode(object),
         lockedEnvironment = {
           object <- copyEnv(object)
           for (nm in ls(object)) rownames(object[[nm]]) <- value
           assayDataEnvLock(object)
         },
         environment = for (nm in ls(object)) rownames(object[[nm]]) <- value,
         list = for (nm in names(object)) rownames(object[[nm]]) <- value,
         )
  object
})

setMethod("combine", c("AssayData", "AssayData"), function(x, y, ...) {
    combineElement <- function(x, y) {
        d <- dim(x)
        if (length(d) != length(dim(y)))
          stop("assayData elements have different dimension lengths: ",
               d, ", ", dim(y))
        if (!all({d==dim(y)}[-2]))
          stop("assayData elements have incompatible dimensions: ",
               d, ", ", dim(y))
        if (length(d)==2) {
            sharedCols <- intersect(colnames(x), colnames(y))
            if (length(sharedCols)>0) {
                if (!identical(x[,sharedCols, drop=FALSE], y[,sharedCols, drop=FALSE])) {
                    diff <- !sapply(sharedCols,
                                    function(nm) identical(x[, nm, drop=FALSE],
                                                           y[, nm, drop=FALSE]))
                    stop("assayData elements must have identical data",
                         "\n\tnon-conforming sample(s): ", 
                         paste(sharedCols[diff], collapse=", "), sep="")
                }
                cbind(x, y[,colnames(y) %in% setdiff(colnames(y), sharedCols), drop=FALSE])
            } else cbind(x,y)
        } else stop("Cannot combine AssayData with dim length ", length(dim(x)))
    }
    storage.mode <- assayDataStorageMode(x)
    nmfunc <- if ("environment"==class(x)) ls else names

    if (assayDataDim(x)[[1]] != assayDataDim(y)[[1]])
      stop("objects have different numbers of features: ",
           assayDataDim(x)[[1]], ", ", assayDataDim(y)[[1]])
    if (assayDataStorageMode(y) != storage.mode)
      stop(paste("assayData must have same storage, but are ",
                 storage.mode, ", ", assayDataStorageMode(y), sep=""))
    if (length(nmfunc(x)) != length(nmfunc(y)))
      stop("assayData have different numbers of elements:\n\t",
           paste(nmfunc(x), collapse=" "), "\n\t",
           paste(nmfunc(y), collapse=" "))
    if (!all(nmfunc(x) == nmfunc(y)))
      stop(paste("assayData have different element names:",
                 paste(nmfunc(x), collapse=" "),
                 paste(nmfunc(y), collapse=" "), sep="\n\t"))
    if ("list" == storage.mode) {
        aData <- lapply(names(x), function(nm) combineElement(x[[nm]],y[[nm]]))
        names(aData) <- names(x)
    } else {
        aData <- new.env(parent=emptyenv())
        for (nm in ls(x)) aData[[nm]] <- combineElement(x[[nm]], y[[nm]])
        if ("lockedEnvironment" == storage.mode) assayDataEnvLock(aData)
    }
    aData
})

assayDataDim <- function(object) {
  nms <- if (assayDataStorageMode(object) == "list") names(object) else ls(object)
  if ( length( nms ) == 0 ) return( NA )
  d <- dim( object[[ nms[[1]] ]])
  names(d) <- c( "Features", "Samples", rep("...", max(length(d)-2, 0)))
  d
}

##FIXME: RG says I don't know if you should ignore non-matrix objects or
## not -  for now I have put in an informative error message
assayDataDims <- function( object ) {
  nms <- if (assayDataStorageMode(object) == "list") names(object) else ls(object)
  if ( length( nms ) == 0 ) return( NA )
  d = sapply(nms, function(i) dim(object[[i]]))
  rownames(d) <- c("Features", "Samples", rep("...", nrow(d)-2))
  colnames(d) <- nms
  d[,order(colnames(d)), drop=FALSE]
}
