require(methods, quietly=TRUE)
