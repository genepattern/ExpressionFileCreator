### Name: aaMap
### Title: names and characteristics of amino acids
### Aliases: aaMap
### Keywords: datasets

### ** Examples

data(aaMap)



