### Name: addVig2Menu
### Title: Add menu items to an existing/new menu of a window
### Aliases: addVig2Menu addVig4Win addVig4Unix addNonExisting addPDF2Vig
### Keywords: interface

### ** Examples

    # Only works for windows now
    if(interactive()){
        addPDF2Menu("Biobase")
    }



