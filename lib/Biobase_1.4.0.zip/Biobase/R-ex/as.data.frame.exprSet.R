### Name: as.data.frame.exprSet
### Title: converts an exprSet to a dataframe
### Aliases: as.data.frame.exprSet
### Keywords: manip

### ** Examples

data(eset)

sd.genes <- esApply(eset, 1, sd)

dataf <- as.data.frame(eset)

dataf <- cbind(dataf, sd.genes=rep(unname(sd.genes), length=nrow(dataf)))

coplot(sd.genes ~ exprs | cov1+cov2, data=dataf)




