### Name: container-class
### Title: container: a class that specializes the list construct of R to
###   provide content and access control
### Aliases: container-class [,container-method length,container-method
###   content,container-method content locked locked,container-method
###   [[<-,container-method [[,container-method show,container-method
### Keywords: methods

### ** Examples

  x1 <- new("container", x=vector("list", length=3), content="lm")
  lm1 <- lm(rnorm(10)~runif(10))
  x1[[1]] <- lm1
 


