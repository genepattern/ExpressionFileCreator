### Name: copyEnv
### Title: Functionality to copy environments
### Aliases: copyEnv list2env env2list
### Keywords: utilities

### ** Examples

   z <- new.env()
   multiassign(c("a","b","c"),c(1,2,3),z)

   a <- copyEnv(z)
   ls(a)

   q <- env2list(z)
   g <- new.env()
   g <- list2env(q,g)   
   ls(g)



