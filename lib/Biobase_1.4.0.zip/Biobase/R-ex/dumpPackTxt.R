### Name: dumpPackTxt
### Title: dump textual description of a package
### Aliases: dumpPackTxt
### Keywords: models

### ** Examples

dumpPackTxt("ctest")



