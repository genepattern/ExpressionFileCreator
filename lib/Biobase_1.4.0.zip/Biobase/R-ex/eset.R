### Name: eset
### Title: A dataset of class exprSet
### Aliases: eset
### Keywords: datasets

### ** Examples

data(eset)



