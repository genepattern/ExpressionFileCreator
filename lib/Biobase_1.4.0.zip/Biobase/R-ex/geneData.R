### Name: geneData
### Title: A subset of some expression data.
### Aliases: geneData geneCov
### Keywords: datasets

### ** Examples

data(geneData)



