### Name: getPkgVigs
### Title: A function to list PDF files for a package
### Aliases: getPkgVigs
### Keywords: utilities

### ** Examples

 z <- getPkgVigs()
 z # and look at them



