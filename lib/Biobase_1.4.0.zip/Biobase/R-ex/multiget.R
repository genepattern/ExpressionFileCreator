### Name: multiget
### Title: Return a list containing the Values of the supplied variables.
### Aliases: multiget
### Keywords: data

### ** Examples

nam <- paste("r",1:6, sep=".")

multiassign(nam, 11:16)
rm("r.3")
multiget(nam, iffail=NA)




