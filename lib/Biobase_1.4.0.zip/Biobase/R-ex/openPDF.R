### Name: openPDF
### Title: A function to view PDF files
### Aliases: openPDF
### Keywords: utilities

### ** Examples

## Not run: openPDF("annotate.pdf")



