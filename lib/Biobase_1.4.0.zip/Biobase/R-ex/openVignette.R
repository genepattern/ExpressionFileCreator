### Name: openVignette
### Title: Open a selected Vignette
### Aliases: openVignette
### Keywords: utilities

### ** Examples

  if( interactive() )
    openVignette("Biobase")



