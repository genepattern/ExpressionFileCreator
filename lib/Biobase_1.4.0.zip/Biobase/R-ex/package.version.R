### Name: package.version
### Title: A function to report package versions
### Aliases: package.version
### Keywords: utilities

### ** Examples

  package.version("Biobase")



