### Name: read.MIAME
### Title: Read MIAME information
### Aliases: read.MIAME
### Keywords: file

### ** Examples

miame <- read.MIAME(widget=FALSE) ##creates an empty instance
show(miame)



