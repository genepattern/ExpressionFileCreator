### Name: read.exprSet
### Title: A function to read experimental data and create an exprSet
###   object using the data read in as a text file
### Aliases: read.exprSet
### Keywords: manip

### ** Examples

# Creating a test data
testFile <- tempfile()
data(geneData)
write.table(geneData, testFile, quote = FALSE, sep = "\t", row.names =
TRUE, col.names = TRUE)
# Create an exprSet object using textFile 
eSet <- read.exprSet(testFile) 
eSet



