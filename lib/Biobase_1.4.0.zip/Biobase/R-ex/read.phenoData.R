### Name: read.phenoData
### Title: Read phenoData
### Aliases: read.phenoData
### Keywords: file

### ** Examples

pd <- read.phenoData(sampleNames=c("sample1","sample2"),widget=FALSE)
show(pd)
show(pData(pd))



