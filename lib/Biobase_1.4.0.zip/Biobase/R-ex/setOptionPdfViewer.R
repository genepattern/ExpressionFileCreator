### Name: setOptionPdfViewer
### Title: A function to set the PDF viewer option
### Aliases: setOptionPdfViewer
### Keywords: utilities

### ** Examples

   setOptionPdfViewer()



