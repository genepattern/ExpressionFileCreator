### Name: testBioCConnection
### Title: A function to check internet connectivity to Bioconductor
### Aliases: testBioCConnection
### Keywords: utilities

### ** Examples

 z <- testBioCConnection()



