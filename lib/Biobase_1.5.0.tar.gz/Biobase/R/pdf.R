openPDF <- function(file, bg=TRUE) {
    OST <- .Platform$OS.type
    if (OST=="windows") {
        shell.exec(file)
    }
    else if (OST == "unix") {
        bioCOpt <- getOption("BioC")
        pdf <- getOption("pdfviewer")
        if (is.null(pdf)) {
            warning(paste("pdfViewer is set to:",pdf,
                          "which does not seem to exist.  Please",
                          "run the command setOptionPdfViewer()"))
            return(FALSE)
        }
        cmd <- paste(pdf,file)
        if( bg )
          cmd <- paste(cmd, "&")
        system(cmd)
    }
    return(TRUE)
}


