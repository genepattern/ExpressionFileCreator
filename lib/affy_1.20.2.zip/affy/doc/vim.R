###################################################
### chunk number 1: 
###################################################
library(affy)


###################################################
### chunk number 2: <
###################################################
getNrowForCEL <- function() max(getPosXForCEL())
getNcolForCEL <- function() max(getPosYForCEL())


