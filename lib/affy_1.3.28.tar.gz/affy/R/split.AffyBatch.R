split.AffyBatch <- function(x, f) {

  sp <- getMethod("split", c("exprSet", "vector"))(x, f)

  sp.abatch <- lapply(sp, function(eset) {
    new("AffyBatch", cdfName = x@cdfName,
        nrow = nrow(x), ncol= ncol(x))
  })

  for (i in seq(along = sp)) {
    ## function to cast classes included in next release
    exprs(sp.abatch[[i]]) <- exprs(sp[[i]])
    se.exprs(sp.abatch[[i]]) <- se.exprs(sp[[i]])
    annotation(sp.abatch[[i]]) <- annotation(sp[[i]])
    phenoData(sp.abatch[[i]]) <- phenoData(sp[[i]])
    description(sp.abatch[[i]]) <- description(sp[[i]])
    notes(sp.abatch[[i]]) <- notes(sp[[i]])
    ## try to lower memory usage
    sp[[i]] <- NA
    gc()
  }

  return(sp.abatch)
  
}


