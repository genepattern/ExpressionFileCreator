  require(Biobase, quietly=TRUE)
  require(modreg, quietly=TRUE)
  require(eda, quietly=TRUE)

  ## DEBUG flag
  ##assign("debug.affy123", TRUE)
  assign("debug.affy123", FALSE)

