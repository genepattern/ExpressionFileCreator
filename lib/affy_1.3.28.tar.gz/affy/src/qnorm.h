#ifndef QNORM_H
#define QNORM_H 1

void qnorm_c(double *data, int *rows, int *cols);

#endif
