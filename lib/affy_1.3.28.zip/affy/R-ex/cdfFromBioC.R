### Name: cdfFromBioC
### Title: Functions to obtain CDF files
### Aliases: cdfFromBioC cdfFromData cdfFromLibPath cdfFromEnvironment
### Keywords: utilities

### ** Examples




