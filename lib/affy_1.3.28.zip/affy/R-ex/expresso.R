### Name: expresso
### Title: From raw probe intensities to expression values
### Aliases: expresso
### Keywords: manip

### ** Examples

data(affybatch.example)

eset <- expresso(affybatch.example, bgcorrect.method="rma",
                 normalize.method="constant",pmcorrect.method="pmonly",
                 summary.method="avgdiff")



