### Name: justRMA
### Title: Read CEL files into an AffyBatch
### Aliases: justRMA just.rma
### Keywords: manip

### ** Examples





