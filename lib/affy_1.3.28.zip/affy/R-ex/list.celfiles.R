### Name: list.celfiles
### Title: List the Cel Files in a Directory/Folder
### Aliases: list.celfiles
### Keywords: character

### ** Examples

list.celfiles()



