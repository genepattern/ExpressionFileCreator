### Name: maffy.subset
### Title: Select Subset
### Aliases: maffy.subset
### Keywords: internal

### ** Examples

     #data(Dilution)
     #x <- log2(pm(Dilution)[,1:3])
     #Index <- maffy.subset(x,subset.size=100)$subset
     #mva.pairs(x[Index,])



