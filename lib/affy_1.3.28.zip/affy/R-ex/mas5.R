### Name: mas5
### Title: MAS 5.0 expression measure
### Aliases: mas5
### Keywords: manip

### ** Examples

  data(affybatch.example)
  eset <- mas5(affybatch.example)



