### Name: merge.AffyBatch
### Title: merge two AffyBatch objects
### Aliases: merge.AffyBatch
### Keywords: manip

### ** Examples

data(affybatch.example)
m.abatch <- merge(affybatch.example, affybatch.example)



