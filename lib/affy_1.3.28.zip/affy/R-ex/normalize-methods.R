### Name: normalize-methods
### Title: Normalize Affymetrix Probe Level Data - methods
### Aliases: normalize.AffyBatch normalize.methods
###   normalize.AffyBatch.methods normalize,AffyBatch-method
###   normalize.methods,AffyBatch-method
### Keywords: manip

### ** Examples

data(affybatch.example)
normalize.methods(affybatch.example)



