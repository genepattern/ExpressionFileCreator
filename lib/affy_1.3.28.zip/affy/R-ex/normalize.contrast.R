### Name: normalize.contrasts
### Title: Normalize intensities using the contrasts method
### Aliases: normalize.contrasts normalize.AffyBatch.contrasts
### Keywords: manip

### ** Examples




