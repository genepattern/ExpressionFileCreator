### Name: pairs.AffyBatch
### Title: plot intensities using 'pairs'
### Aliases: pairs.AffyBatch
### Keywords: hplot

### ** Examples




