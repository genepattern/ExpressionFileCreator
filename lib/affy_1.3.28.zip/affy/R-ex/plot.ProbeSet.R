### Name: plot.ProbeSet
### Title: plot a probe set
### Aliases: plot.ProbeSet
### Keywords: hplot

### ** Examples

data(SpikeIn)
plot(SpikeIn)



