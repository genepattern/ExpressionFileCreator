### Name: plotDensity
### Title: Plot Densities
### Aliases: plotDensity plotDensity.AffyBatch
### Keywords: hplot

### ** Examples

data(affybatch.example)

m <- exprs(affybatch.example)

plotDensity(exprs(affybatch.example))




