### Name: read.affybatch
### Title: Read CEL files into an AffyBatch
### Aliases: read.affybatch ReadAffy
### Keywords: manip

### ** Examples





