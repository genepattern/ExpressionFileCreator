### Name: read.probematrix
### Title: Read CEL file data into PM or MM matrices
### Aliases: read.probematrix
### Keywords: manip

### ** Examples





