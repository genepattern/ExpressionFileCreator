### Name: rma
### Title: Robust Multi-Array Average expression measure
### Aliases: rma
### Keywords: manip

### ** Examples

data(affybatch.example)
eset <- rma(affybatch.example)



