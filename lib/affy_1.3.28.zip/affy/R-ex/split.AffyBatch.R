### Name: split.AffyBatch
### Title: split an AffyBatch
### Aliases: split.AffyBatch
### Keywords: manip

### ** Examples

data(affybatch.example)

f <- factor(c("a", "a", "b"))

s.a <- split(affybatch.example, f)




