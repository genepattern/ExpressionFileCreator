  require("methods", quietly=TRUE)
  require("utils", quietly=TRUE)
  require("Biobase", quietly=TRUE)

  ## DEBUG flag
  ##assign("debug.affy123", TRUE)
  assign("debug.affy123", FALSE)

