### Name: exp.farms
### Title: Factor Analysis for Robust Microarray Summarization
### Aliases: exp.farms
### Keywords: manip

### ** Examples

  data(affybatch.example)
  eset <- exp.farms(affybatch.example, weight=8, scale=1.5)



