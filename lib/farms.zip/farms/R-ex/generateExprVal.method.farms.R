### Name: generateExprVal.method.farms
### Title: Generate an expression value from the probes informations
### Aliases: generateExprVal.method.farms
### Keywords: manip

### ** Examples

  data(SpikeIn) ##SpikeIn is a ProbeSets
  probes <- pm(SpikeIn)
  exprs.farms <- generateExprVal.method.farms(probes)



