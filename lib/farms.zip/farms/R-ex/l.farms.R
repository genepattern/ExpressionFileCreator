### Name: l.farms
### Title: l.farms expression measure
### Aliases: l.farms
### Keywords: manip

### ** Examples

  data(affybatch.example)
  eset <- l.farms(affybatch.example)



