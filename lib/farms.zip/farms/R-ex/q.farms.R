### Name: q.farms
### Title: q.farms expression measure
### Aliases: q.farms
### Keywords: manip

### ** Examples

  data(affybatch.example)
  eset <- q.farms(affybatch.example)



