### Name: bg.correct.gcrma
### Title: Background Correction Using sequence information
### Aliases: bg.correct.gcrma
### Keywords: manip

### ** Examples

 require(affydata)
data(Dilution)
Dil.adj<-bg.correct.gcrma(Dilution,gcgroup=getGroupInfo(Dilution),estimate="mle")


