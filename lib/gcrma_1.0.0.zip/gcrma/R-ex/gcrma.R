### Name: gcrma
### Title: Robust Multi-Array expression measure using sequence information
### Aliases: gcrma
### Keywords: manip

### ** Examples

require(affydata)
data(Dilution)
Dil.expr<-gcrma(Dilution,estimate="mle",summary.method = "medianpolish",summary.subset=geneNames(Dilution)[1:10])




