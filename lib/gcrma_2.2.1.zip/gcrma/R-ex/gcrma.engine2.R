### Name: gcrma.engine2
### Title: GCRMA background adjust engine(internal function)
### Aliases: gcrma.engine2
### Keywords: manip

### ** Examples




