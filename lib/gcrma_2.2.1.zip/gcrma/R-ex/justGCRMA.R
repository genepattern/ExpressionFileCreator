### Name: justGCRMA
### Title: Compute GCRMA Directly from CEL Files
### Aliases: justGCRMA just.gcrma
### Keywords: manip

### ** Examples





