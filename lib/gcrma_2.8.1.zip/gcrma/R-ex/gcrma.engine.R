### Name: gcrma.engine
### Title: GCRMA background adjust engine(internal function)
### Aliases: gcrma.engine
### Keywords: manip

### ** Examples





