### Name: read.cdffile
### Title: Read a CDF file
### Aliases: read.cdffile
### Keywords: file

### ** Examples

fn <- system.file("extdata", "Hu6800.CDF.gz", package="makecdfenv")
mycdf <- read.cdffile(fn, compress=TRUE)
mycdf



