### Name: make.cdf.env
### Title: CDF Environment Maker
### Aliases: make.cdf.env
### Keywords: manip

### ** Examples

  env <- make.cdf.env("Hu6800.CDF.gz",
           cdf.path=system.file("extdata", package="makecdfenv"),
           compress=TRUE)
  length(ls(env))
  get("U53347_at", env)    



