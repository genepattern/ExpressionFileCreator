### Name: make.cdf.package
### Title: CDF Environment Package Maker
### Aliases: make.cdf.package
### Keywords: manip

### ** Examples

  pkgpath <- tempdir()
  make.cdf.package("Hu6800.CDF.gz",
           cdf.path=system.file("extdata", package="makecdfenv"),
           compress=TRUE, species = "Homo_sapiens",
           package.path = pkgpath)
  dir(pkgpath)     



