.First.lib <- function(lib, pkgname, where) {
  require(matchprobes)
  
  ## load the data
  thepath = .path.package(pkgname)
  where   =  as.environment(match(paste("package:", pkgname, sep = ""),search()))

  for (f in dir(file.path(thepath, "data"), pattern = ".rda", full.names=TRUE))
    load(f, envir = where)
}
