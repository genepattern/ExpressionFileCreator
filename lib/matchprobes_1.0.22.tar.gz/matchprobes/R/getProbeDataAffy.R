## A function that reads tab-delimited probe sequence
## (and other stuff) files from Affymetrix
getProbeDataAffy <- function(arraytype, datafile,
                             pkgname = NULL, comparewithcdf = TRUE)
{  
  require(affy) || stop("Could not load library affy.")

  if(missing(datafile))
    datafile <- paste(arraytype, "_probe_tab", sep="")
  
  arraytype = cleancdfname(arraytype, addcdf=FALSE)
  cdfname   = cleancdfname(arraytype)
  if (is.null(pkgname))
    pkgname = paste(arraytype, "probe", sep="")

  ##LG: if (identical(grep(paste("^", .Platform$file.sep, sep=""), datafile), integer(0)))
  ##LG:   datafile <- file.path(datadir, datafile)
  ##WH: Laurent, please leave this code inactive.
  ##WH: datafile may also be a connection, and this code would break with that.
  ##WH: I like to keep things simple. If you need to paste a directory path
  ##WH: in front of 'datafile', then please do so before calling this function.
  
  what = list("character", "numeric", "numeric", "numeric", "character", "character")
  head <- scan(datafile, sep="\t", quiet=TRUE, multi.line = FALSE, nlines=1, what="character")
  dat  <- scan(datafile, sep="\t", quiet=TRUE, multi.line = FALSE, skip=1,  what=what)

  if(any(unlist(head) != c("Probe Set Name", "Probe X", "Probe Y", 
     "Probe Interrogation Position", "Probe Sequence", "Target Strandedness"))) {
      mess = paste("The data file", datafile, "does not have the expected column names",
         "in its header line. Please make sure it is the right data file. If you are",
         "positive, you may need to write a customized data import function",
         "to replace 'getProbeDataAffy'. You may use 'getProbeDataAffy' as a template.",
         "Please see the help files for the functions 'getProbeDataAffy' and",
         "'MakeProbePackage', and the vignette for the package matchprobes.\n")
      stop(mess)
    }

  for (i in which(what=="numeric")) {
    z = which(is.na(dat[[i]]))
    if(length(z)>0) 
      stop(paste("Corrupted data file: found non-number in line ", z[1],
                 " of column ", head[i], ": ", dat[z[1], i]), sep="") 
  }

  ## data frame with the probe data
  pt = data.frame(sequence = I(dat[[5]]),           ## character
                  x        = as.integer(dat[[2]]),  ## integer
                  y        = as.integer(dat[[3]]),  ## integer
                  Probe.Set.Name               = I(dat[[1]]),          ## character 
                  Probe.Interrogation.Position = as.integer(dat[[4]]), ## integer
                  Target.Strandedness          = dat[[6]])             ## factor
  class(pt) = c("probetable", class(pt))

  
  ## assign
  dataEnv = new.env()
  assign(pkgname, pt, envir=dataEnv)

  datasource = "The probe sequence data was obtained from \\\\url{http://www.affymetrix.com}."
  if(is.character(datafile))
    datasource = paste(datasource, " The file name was \\\\code{", datafile, "}.", sep="")

  symVal = list(ARRAYTYPE  = arraytype,
    DATASOURCE = datasource,
    NROW       = as.character(nrow(pt)),
    NCOL       = as.character(ncol(pt)))

  if(comparewithcdf) .lgExtraParanoia(pt, cdfname)
  
  return(list(pkgname = pkgname, symVal = symVal, dataEnv = dataEnv))
}
