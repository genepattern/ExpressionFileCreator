getProbeData_1lq <- function(arraytype, datafile, pkgname = NULL)
{  
  if (is.null(pkgname))
    pkgname = paste(arraytype, "probe", sep="")

  ## X        Y          SEQUENCE  DESTYPE
  ## FEATURE  QUALIFIER  EXPOS     PLEN
  ## POS      CBASE      PBASE     TBASE        
  ## IPBASE   UNIT       BLOCK     ATOM
  int = as.integer(0)
  chr = as.character("")
  what=list(int, int, chr, chr,
            chr, chr, int, int, 
            int, chr, chr, chr,
            chr, int, int, int)
  toFactor = c(0,0,0,1,
               1,1,0,0,
               0,1,1,1,
               1,0,0,0)
  use = c(1:4, 6:12, 14, 16)
  
  hd  = scan(datafile, sep="\t", quiet=TRUE, multi.line = FALSE, skip=2, what="character", nlines=1)
  dat = scan(datafile, sep="\t", quiet=TRUE, multi.line = FALSE, skip=3,  what=what, na.strings="!")

  nr = unique(listLen(dat))
  stopifnot(length(nr)==1, length(dat)==length(hd))
  cat(length(hd),"columns and", nr, "rows.\n")
  
  hd = tolower(hd)
  for(i in which(toFactor!=0))
    dat[[i]] = factor(dat[[i]])
   
  ## assign
  dataEnv = new.env()
  assign(pkgname, new.env(), envir=dataEnv)
  for(i in use)
    assign(hd[i], dat[[i]], envir=get(pkgname, envir=dataEnv))
           
  datasource = "The probe sequence data was obtained from \\\\url{http://www.affymetrix.com}."
  if(is.character(datafile))
    datasource = paste(datasource, " The file name was \\\\code{", datafile, "}.", sep="")

  symVal = list(ARRAYTYPE  = arraytype,
    DATASOURCE = datasource,
    NROW       = as.character(nr),
    NCOL       = as.character(length(hd)))

  return(list(pkgname = pkgname, symVal = symVal, dataEnv = dataEnv))
}

