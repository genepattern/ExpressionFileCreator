print.probetable = function(x, ...) {
  cat("Object of class", class(x), "with", nrow(x), "rows and", ncol(x), "columns.\n")
}
