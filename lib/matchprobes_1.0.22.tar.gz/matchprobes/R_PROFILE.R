require("Biobase") || stop("package matchprobes requires Biobase")
