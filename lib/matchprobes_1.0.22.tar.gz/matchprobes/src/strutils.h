char compbase(char c);
extern char* errmess;
