### Name: combineAffyBatch
### Title: A function to combine data from different Affymetrix genechip
###   types into one AffyBatch.
### Aliases: combineAffyBatch
### Keywords: manip

### ** Examples

  ## see vignette!



