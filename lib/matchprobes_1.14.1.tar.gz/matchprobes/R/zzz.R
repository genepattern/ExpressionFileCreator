.First.lib <- function(libname, pkgname) {
  library.dynam("matchprobes", pkgname, libname)
  if(.Platform$OS.type == "windows" && interactive()
     && .Platform$GUI ==  "Rgui" && require(Biobase)) {
      addVigs2WinMenu("matchprobes")
  }
}
