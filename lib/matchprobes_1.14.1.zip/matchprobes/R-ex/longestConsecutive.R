### Name: longestConsecutive
### Title: Obtain the length of the longest substring containing only
###   'letter'
### Aliases: longestConsecutive
### Keywords: manip

### ** Examples

 v = c("AAACTGTGFG", "GGGAATT", "CCAAAAAAAAAATT")
 longestConsecutive(v, "A")



