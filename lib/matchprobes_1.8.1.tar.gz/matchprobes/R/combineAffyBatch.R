##------------------------------------------------------------
## (c) Wolfgang Huber 2003
##------------------------------------------------------------
combineAffyBatch <- function(batch, probepkg, newcdf,
                    verbose=TRUE) {
  
  ## the "reference" chip type
  REFCHIP <- 1
  ## bureaucracy
  if(!is.character(probepkg))
    stop("'probepkg' must be a character vector")
  if(!is.list(batch))
    stop("'batch' must be a list")
  if(any(sapply(batch, class)!="AffyBatch"))
    stop("Elements of 'batch' must have class AffyBatch")
  if(missing(newcdf))
    stop("Argument \"newcdf\" is missing, with no default.\nPlease specify the name of the new CDF environment.")

  require(affy)
  
  ## number of AffyBatches  
  nrbatch <- length(batch)
  stopifnot(length(probepkg)==nrbatch)

  ## number of arrays with each AffyBatch
  batchlength <- sapply(batch, length)

  upp   <- unique(probepkg)
  nrupp <- length(upp)
  if(nrupp<=1)
    stop("You have got nothing to combine.\n")
  
  for (lib in upp)
    require(lib, character.only=TRUE)
  
  uppname      = paste("package", upp, sep=":")
  probepkgname = paste("package", probepkg, sep=":")
  
  ## here we use the fact that the MM probes are always "one below"
  ## the PM probes, i.e. if PM is at (x,y), MM is at (x, y+1)
  pm.index <- function(x,y,nr)     y*nr + x + 1
  mm.index <- function(x,y,nr) (y+1)*nr + x + 1

  ## pm[[i]] and mm[[i]] map from the table probepkg[[i]] into the AffyBatch
  pm = mm = sequs = vector(mode="list", length=nrupp)
  for (i in 1:nrupp) {
    ibatch = match(upp[i], probepkg)
    if(verbose)
      cat(uppname[i], probepkg[ibatch], "\n", sep="\t")
    
    tmp <- get(upp[i], uppname[i])
    if(!is.data.frame(tmp) || !all(c("x", "y", "sequence") %in% colnames(tmp)))
      stop(paste(uppname[i], "is not a valid probe package."))
    
    pm[[i]]  <- pm.index(tmp$x, tmp$y, nrow(batch[[ibatch]]))
    mm[[i]]  <- mm.index(tmp$x, tmp$y, nrow(batch[[ibatch]]))
    sequs[[i]] <- tmp$sequence
  }
  rm(tmp)
  
  ##----------------------------------------------------------------------
  ## cseqs: a logical vector of length = length(sequs[[REFCHIP]])
  ## TRUE if a probe is on all the arrays
  ##----------------------------------------------------------------------
  lseqs <- rep(TRUE, length(sequs[[REFCHIP]]))

  ## For i==REFCHIP, the %in% is redundant but the code is simpler so 
  for(i in 1:nrupp) {
    lseqs <-  lseqs & (sequs[[REFCHIP]] %in% sequs[[i]])
    ## cat(sum(lseqs), "probes in common between", paste(upp[1:i], collapse=", "), "and", probepkg[REFCHIP], "\n")
  }
  cseqs <- unique(sequs[[REFCHIP]][lseqs])
  nrcommon = length(cseqs)
  cat(nrcommon, "unique probes in common\n")

  ## pind: the matrix of first occurences of all unique probes
  pind <- matrix(NA, nrow=nrcommon, ncol=nrupp)
  for(i in 1:nrupp) {
    pind[,i] <- match(cseqs, sequs[[i]])
  }
  stopifnot(!any(is.na(pind)))

  ## for debugging
  for(i in 2:nrupp)
    stopifnot(all(sequs[[1]][pind[,1]] == sequs[[i]][pind[,i]]))
  stopifnot(!any(duplicated(sequs[[1]][pind[,1]])))
   
  ## create new CDF environment
  assign(newcdf, new.env(hash=TRUE, parent=emptyenv()))

  use <- sequs[[REFCHIP]] %in% cseqs
  probesets <- split(sequs[[REFCHIP]][use],
                     f = get(probepkg[REFCHIP], probepkgname[REFCHIP])$Probe.Set.Name[use])
   
  psids <- names(probesets)

  for (i in 1:length(probesets)){
    ps <- probesets[[i]]  ## vector of sequences
    csi <- match(ps, cseqs)
    csi <- csi[!is.na(csi)]
    ## cat(psids[i], length(csi), "  ")
    if(length(csi)==0) next  ## probeset for which we have no information
    mat = cbind(csi, csi+length(cseqs))
    colnames(mat) = c("pm", "mm")
    assign(psids[i], mat, env=get(newcdf))
  }
   
  ## probepkg is the list of packages, and may contain the same ones several times
  ## upp are the unique ones
  ## pkgoff maps one to the other
  pkgoff = match(probepkg, upp)

  ## ----------------------------------------------------------------------
  ## join the expression value table
  x <- matrix(NA, nrow = nrcommon*2, ncol = sum(batchlength))
  j <- 0
  for(i in 1:nrbatch) {
    k     <- pkgoff[i]
    xcols <- j + (1:batchlength[i])
    x[, xcols] <- exprs(batch[[i]])[c(pm[[k]][pind[,k]], mm[[k]][pind[,k]]), ]
    j <- j + batchlength[i]
  }

  pd <- do.call("combine", lapply(batch, phenoData))
  rownames(pData(pd)) <- colnames(x) <- unlist(lapply(seq(along=batch),function(i)
                      paste("Batch ", i, ": ", sampleNames(batch[[i]]), sep="")))
  
  lapply(uppname, function(x) { do.call("detach", list(x)) })

  return(list(dat = new("AffyBatch", exprs=x,
                        phenoData=pd,
                        cdfName = newcdf, 
                        nrow=0, ncol=0),
              cdf = get(newcdf)))
}
