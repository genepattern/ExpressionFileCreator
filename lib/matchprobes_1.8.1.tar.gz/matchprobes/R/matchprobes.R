matchprobes <- function(query, records, probepos=FALSE) 
   .Call("MP_matchprobes", toupper(query), toupper(records), probepos, PACKAGE="matchprobes")

complementSeq <- function(seq, start=1, stop=0) 
  .Call("MP_complementSeq", seq, as.integer(start), as.integer(stop), PACKAGE="matchprobes")
  
reverseSeq  <- function(seq)
  .Call("MP_revstring", seq, PACKAGE="matchprobes")

longestConsecutive <- function(seq, letter) 
  .Call("MP_longestConsecutive", seq, letter, PACKAGE="matchprobes")

basecontent <- function(seq) {
  good   = !is.na(seq)
  havena = !all(good)
  if(havena)
    seq = seq[good]
  
  rv = .Call("MP_basecontent", seq, PACKAGE="matchprobes")

  if(havena) {
    z = rv
    rv = matrix(NA, nrow=length(good), ncol=ncol(z))
    colnames(rv) = colnames(z)
    rv[good, ] = z
  }
  
  class(rv) <- c("probetable", class(rv))
  return(rv)
}
