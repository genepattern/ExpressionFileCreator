char compbase(char c);

