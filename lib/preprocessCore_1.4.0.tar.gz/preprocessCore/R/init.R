.First.lib <- function(libname, pkgname) {

  library.dynam("preprocessCore",pkgname,libname,now=FALSE)

}
