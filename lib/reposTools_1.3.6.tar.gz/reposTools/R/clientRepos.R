reposToolsCurrentInstalls <- list()

syncLocalLibList <- function(lib=reposToolsLibPaths()) {
    ## Need to see if there currently exists a 'liblisting.Rda' in lib
    ## if so, load it, otherwise set the object NULL
    cat("\nSynching your local package management information ...\n")

    ## Create a locale for any temporary lib dirs, if needed
    tmpLibDir <- file.path(tempdir(),"tempLibs")
    if (! file.exists(tmpLibDir))
        dir.create(tmpLibDir)

    ## Need to convert any old style local libraries to new style
    convert.locLib(lib)

    ## Now sync the local pkg info
    for (i in seq(along=lib)) {
        if (!file.exists(lib[i]))
            next

        ## Check to make sure we can write to this lib
        if (file.access(lib[i],mode=2) != 0) {
            cat("\n\t")
            note(paste("reposTools can not access ",lib[i],".\n\t",
                       "This will not affect your R session unless ",
                       "you wish \n\tto install/update/remove packages ",
                       "from this directory\n",sep=""))
            writeable <- FALSE
        }
        else
            writeable <- TRUE


        if (load.locLib(lib[i]) == FALSE) {
            locLibList <- NULL
        }

        if (length(dir(lib[i])) > 0) {
            ## Get listing of all packages installed in this library
            options(show.error.messages=FALSE)
            on.exit(options(show.error.messages=TRUE), add=TRUE)
            pkgs <- try(installed.packages(lib[i]))
            options(show.error.messages=TRUE)
            if (is(pkgs,"try-error")) {
                warning(paste(lib[i],"does not seem to be a valid",
                              "R package library, skipping ..."))
                next
            }

            ## Figure out which packages are already in the database,
            ## and which ones are new
            curLocPkgs <- unlist(lapply(locLibList, Package))
            oldPkgs <- pkgs[,"Package"] %in% curLocPkgs
            old <- pkgs[oldPkgs,,drop=FALSE]
            new <- pkgs[!oldPkgs,,drop=FALSE]
            gonePkgs <- which(!(curLocPkgs %in% pkgs[,"Package"]))

            if (nrow(old) > 0) {
                ## Need to find any updated packages ...
                remPkgs <- numeric()
                for (j in 1:nrow(old)) {
                    ## For each package, check to see if any of its
                    ## version has changed, if so, add it to the 'new' list
                    llPkg <- match(old[j,"Package"],curLocPkgs)
                    if (buildVersionNumber(old[j,"Version"])
                        != PkgVersion(locLibList[[llPkg]])) {
                        new <- rbind(new,old[j,])
                        remPkgs <- c(remPkgs, llPkg)
                    }
                }
                if (length(remPkgs) > 0)
                    locLibList <- locLibList[-remPkgs]
            }

            if (nrow(new) > 0) {
                locLibFields <- c("Package","Version","Keywords","Repos",
                                  "Depends", "Suggests", "Uses")
                ## Extract the information for any new packages
                locLibMtrx <- matrix(nrow=nrow(new),ncol=length(locLibFields))
                colnames(locLibMtrx) <- locLibFields
                pkgsFlds <- colnames(locLibMtrx)[colnames(locLibMtrx) %in% colnames(pkgs)]
                locLibMtrx[,pkgsFlds] <- new[,pkgsFlds]
                locLibMtrx[is.na(locLibMtrx)] <- "NA"
                ## Convert versions to VersionNumber
                vers <- locLibMtrx[,"Version"]
                versList <- list()
                for (k in 1:length(vers)) {
                    versList[[k]] <- buildVersionNumber(vers[k])
                }

                for (l in 1:nrow(locLibMtrx))
                    locLibList[[length(locLibList)+1]] <- new("localPkg",
                                                          Package=locLibMtrx[l,1],
                                                          PkgVersion=versList[[l]],
                                                          Keywords=locLibMtrx[l,3],
                                                          Repos=locLibMtrx[l,4],
                                                          Depends=locLibMtrx[l,5],
                                                          Suggests=locLibMtrx[l,6],
                                                          Uses=locLibMtrx[l,7])

                outNewPkgs <- paste(locLibMtrx[,"Package"], collapse="\n\t")
                ## If this is a non-writeable directory, packages
                ## there will show up as "new" but they shouldn't
                ## be reported.
                if (writeable)
                    cat("Packages which have been added/updated:",
                        outNewPkgs,"\n",sep="\n\t")
            }


            if (length(gonePkgs) > 0) {
                ## Also need to detect removed packages
                outPkgs <-
                    paste(curLocPkgs[gonePkgs],collapse="\n\t")
                cat("Packages which have been removed:",outPkgs,"\n",
                    sep="\n\t")
                locLibList <- locLibList[-(gonePkgs)]
            }

            if (writeable)
                save.locLib(locLibList, lib[i])
            else {
                ## !! write the locliblist to a temporary directory
                curDir <- tempfile(tmpdir=tmpLibDir)
                dir.create(curDir)
                save.locLib(locLibList, curDir)
            }
        }
    }
}

load.locLib <- function(lib=reposToolsLibPaths()[1]) {
    if (length(lib) != 1) {
        warning("load.locLib() does not accept vectorized inputs")
        return(FALSE)
    }

    libFile <- file.path(lib,"liblisting.Rda")
    if (file.exists(libFile)) {
        load(libFile,envir=parent.frame())
        return(TRUE)
    }
    else {
        return(FALSE)
    }
}

closeLocLib <- function() {
    ## Removes the locLibList w/o saving
    ## Probably unecessary in most cases, but can be used to prevent
    ## confusion.
    if ("locLibList" %in% ls(envir=parent.frame()))
        rm("locLibList",envir=parent.frame())
}

save.locLib <- function(locLibList, lib) {
    locLibList
    libFile <- file.path(lib,"liblisting.Rda")

    if (file.access(lib,mode=2) == 0) {
        save(locLibList, file=libFile)
    }
    else {
       warning(paste("Incorrect permissions to edit package database,",
                   libFile))
    }
}

convert.locLib <- function(libs=reposToolsLibPaths()) {
    ## Will convert a liblisting.Rda file from the old style
    ## (pre-1.1.39 reposTools) to the new structure

    for (lib in libs) {
        if (load.locLib(lib) == FALSE)
            next
        if ("locLibDf" %in% ls()) {
            cat("\nConverting",lib,"to new local library data format.\n")
            if (is.data.frame(locLibDf)) {
                locLibList <- list()
                for (i in 1:nrow(locLibDf)) {
                    ## The Depends field in the old locLibDf was often
                    ## messed up and included a lot of garbage.  We
                    ## need to filter out that garbage.
                    curDepends <- locLibDf[i,"Depends"][[1]]
                    curDepends <- gsub("(\\\\)|(\")|(\))|(c\\()","",curDepends)

                    locLibList[[length(locLibList)+1]] <-
                        new("localPkg", Package=as.character(locLibDf[i,"Package"]),
                            PkgVersion=locLibDf[i,"Version"][[1]],
                            Keywords=locLibDf[i,"Keywords"][[1]],
                            Repos=as.character(locLibDf[i,"Repos"]),
                            Depends=curDepends,
                            Suggests=locLibDf[i,"Suggests"][[1]],
                            Uses=locLibDf[i,"Uses"][[1]])
                }
                save.locLib(locLibList, lib)
            }
        }
    }
}

getLocalPkgs <- function(libs=reposToolsLibPaths()) {
    pkgInfos <- list()

    for (lib in libs) {
        if (load.locLib(lib) == FALSE) {
            next
        }

        pkgs <- lapply(locLibList, Package)
        vers <- lapply(locLibList, PkgVersion)

        for (i in seq(along=pkgs))
            pkgInfos[[i]] <-buildPkgInfo(as.character(pkgs[[i]]), vers[i][[1]])

        closeLocLib()
    }

    return(pkgInfos)
}

findInstallDepends <- function(pkg, vers, libList, depColName, remove=FALSE) {
    out <- NULL
    if (length(libList) == 0)
        return(out)

    depCol <- switch(depColName,
                     "Depends"=lapply(libList,Depends),
                     "Suggests"=lapply(libList,Suggests),
                     "Uses"=lapply(libList,Uses),
                     stop("Invalid depColName"))

    for (i in 1:length(depCol)) {
        curDeps <- depCol[[i]]
        if ((length(curDeps) == 1)&&(curDeps == "NA"))
            next
        if (length(curDeps) != 0) {
            depMtrx <- getDepMtrx(curDeps)
            if (is.null(depMtrx))
                next

            if (length(row <- grep(paste("^",pkg,"$",sep=""),
                                   depMtrx[,1])) > 0) {
                if (remove == TRUE) {
                    ## This is going to break a depency no matter what
                    out <- c(out,paste(Package(libList[[i]]),"version",
                                       stringRep(PkgVersion(libList[[i]])),
                                       "depends on",
                                       depMtrx[row,1],depMtrx[row,2]))
                }
                else if (depMtrx[row,2] != "") {
                    ## Specific version requirement.  If they're not
                    ## removing the file, and there's no version req
                    ## then no dep problem
                    if (checkVers(vers,getReqOper(depMtrx[row,2]),
                                  getReqVers(depMtrx[row,2])) == FALSE) {
                        ## Broken dependency
                        out <- c(out,paste(Package(libList[[i]]),"version",
                                           stringRep(PkgVersion(libList[[i]])),
                                           "depends on",
                                           depMtrx[row,1],depMtrx[row,2]))
                    }
                }
            }
        }
    }
    return(out)
}

is.installed <- function(pkg, vers=NULL,
                         verbose=TRUE, oper="==", libs) {
    ## Given a package name will check to see if it is installed
    ## if vers != NULL, will look for a specific version
    ## if oper != NULL and vers != NULL, won't look for a specific
    ## version, but rather will look to see if there's a version
    ## that satifies 'version oper vers'
    if ((!is.null(vers))&&(class(vers) != "VersionNumber"))
        vers <- buildVersionNumber(vers)

    if (missing(libs))
        libs <- reposToolsLibPaths()

    for (lib in libs) {
        if (load.locLib(lib)) {
            locPkgs <- unlist(lapply(locLibList, Package))
            whichPkg <- which(locPkgs == pkg)

            if (length(whichPkg) != 0) {
                ## Found package
                if (is.null(vers)) {
                    return(TRUE)
                }
                else {
                    pkgVers <- lapply(locLibList[whichPkg],PkgVersion)
                    if (any(unlist(lapply(pkgVers,checkVers, oper,vers))))
                        return(TRUE)
                }
            }
            closeLocLib()
        }
        else {
            if (verbose == TRUE)
                note(paste("No locliblisting in R library",lib))
        }
    }
    return(FALSE)
}

getPkgVers <- function(pkg, libs=reposToolsLibPaths(), verbose=TRUE) {
    ## Will get the version of an installed package
    ## returns a list of versions if multiple installs
    ## returns an empty list if not intalled
    vers <- list()
    for (lib in libs) {
        if (load.locLib(lib)) {
            locPkgs <- unlist(lapply(locLibList, Package))
            whichPkg <- which(locPkgs == pkg)
            if (length(whichPkg) > 0) {
                vers[length(vers)+1] <- lapply(locLibList, PkgVersion)[whichPkg]
            }
            closeLocLib()
        }
        else {
            if (verbose == TRUE)
                note(paste("No locliblisting in R library",lib))
        }
    }
    return(vers)
}

getLocLibURLs <- function(pkgs, lib) {
    ## match up any requested packages to
    ## the 'Repos' field of the locLib.

    if (load.locLib(lib) == FALSE) {
        return(NULL)
    }
    locPkgs <- unlist(lapply(locLibList, Package))
    urls <- unlist(lapply(locLibList,Repos))
    urls <- urls[match(pkgs,locPkgs)]
    if (all(is.na(urls)))
        return(NULL)

    closeLocLib()
    return(as.vector(urls))
}

updateLocLib <- function(lib, pkg, vers, repEntry) {
    if (load.locLib(lib) == FALSE) {
        syncLocalLibList(lib)
        load.locLib(lib)
    }

    if (!is(vers,"VersionNumber"))
        vers <- buildVersionNumber("0")

    pI <- buildPkgInfo(pkg, vers)

    newPkg <- new("localPkg", Package=pkg, PkgVersion=vers,
                  Keywords=keywords(repEntry, pI),
                  Depends=depends(repEntry, pI),
                  Suggests=suggests(repEntry, pI),
                  Uses=uses(repEntry, pI),
                  Repos=repURL(repEntry))

    listPkg <- length(locLibList)
    curPkgs <- unlist(lapply(locLibList, Package))
    if (is.na(oP <- match(pkg, curPkgs)))
        listPkg <- listPkg + 1
    else
       listPkg <- oP

        locLibList[[listPkg]] <- newPkg

    save.locLib(locLibList, lib)
    return(TRUE)
}

resolve.depends <- function(pkg, repEntry, force=FALSE,
                            forward=TRUE, libs=reposToolsLibPaths(),
                            remove=FALSE, depends=TRUE,
                            suggests=TRUE, uses=FALSE,
                            searchOptions=TRUE, getAllDeps=FALSE,
                            versForce=TRUE, method="auto", getNewest=FALSE) {
    ## Passed a pkgInfo object.  Will make sure this package does not
    ## break any current dependencies - it will error if trying a
    ## level w/ a FALSE value, and warn if TRUE.
    errors <- c(depends,suggests,uses)
    if (length(which(errors)) > 0) {
        levels <- c("Depends","Suggests","Uses")
        halt <- FALSE
        out <- NULL

        retEnv <- new.env()
        retPSlist <- new("pkgStatusList",statusList=list())

        for (lib in libs) {
            if (load.locLib(lib) == TRUE) {
                for (i in seq(along=levels)) {
                    ## Find any "reverse" depends - ie if this breaks anything
                    ## currently installed
                    out <- c(out,findInstallDepends(pkgName(pkg),pkgVersion(pkg),
                                                    locLibList, levels[i],
                                                    remove))

                    if (forward == TRUE) {
                        ## Now check for forward depends, if they need
                        ## to obtain any other packages
                        fdEnv <- solveForwardDepends(pkg, repEntry,
                                                     lib, levels[i],
                                                     searchOptions=searchOptions,
                                                     getAllDeps=getAllDeps,
                                                     method=method,
                                                     getNewest=getNewest)
                        out <- c(out,get("out",fdEnv))
                        statusList(retPSlist) <- get("pkgList",fdEnv)

                    }
                    if ((!is.null(out))&&(errors[i] == TRUE))
                        halt <- TRUE
                }
                closeLocLib()
                if (!is.null(out)) {
                    if ((halt == TRUE)&&(force==FALSE)) {
                        warning(paste("\n",paste(out,collapse="\n"),"\n"))
                        assign("halt",TRUE,retEnv)
                    }
                    else
                        assign("halt",FALSE,retEnv)
                }
                else {
                    assign("halt",FALSE,retEnv)
                }
            }
        }
    }
    assign("pkgList",retPSlist,retEnv)
    return(retEnv)
}

solveForwardDepends <- function(pkgInfo, repEntry, lib, depLevel,
                                searchOptions=TRUE,getAllDeps=FALSE,
                                versForce=TRUE, method="auto",
                                getNewest=getNewest) {
    pkg <- pkgName(pkgInfo)
    vers <- pkgVersion(pkgInfo)
    curPkgInfo <- new("pkgInfo", pkgName=pkg, pkgVersion=vers)

    ## Begin a hack to double check for circular references
    cIlen <- length(reposToolsCurrentInstalls)+1
    reposToolsCurrentInstalls[[cIlen]] <<- curPkgInfo

    out <- NULL

    retEnv <- new.env()
    retPSlist <- new("pkgStatusList",statusList=list())

    curMtrx <- switch(depLevel,
                      "Depends"=getDepMtrx(depends(repEntry, pkgInfo)),
                      "Suggests"=getDepMtrx(suggests(repEntry, pkgInfo)),
                      "Uses"=getDepMtrx(uses(repEntry, pkgInfo))
                      )
    ## Now have a dependency matrix for this package on the
    ## current level of depends
    for (i in seq(along=curMtrx[,1])) {
        depPkg <- curMtrx[i,1]
        ## If this is a R depend and it has a version (we already
        ## know they have *a* version of R), check it
        if (depPkg == "R") {
            if (curMtrx[i,2]!="") {
                ## Handle R depends differently
                curRvers <- getRversion()
                depVers <- getReqVers(curMtrx[i,2])
                depOper <- getReqOper(curMtrx[i,2])
                if (checkVers(curRvers, depOper, depVers) == FALSE)
                {
                    out <- c(out, paste("Package",pkg,"version",
                                        vers, "requires R version",
                                        depVers,"but you only have",curRvers,
                                        "- please see www.r-project.org to",
                                        "upgrade your R install.\n"))
                }
            }
        }
        else {
            ## Package dependency
            if (curMtrx[i,2] != "") {
                depVers <- getReqVers(curMtrx[i,2])
                depOper <- getReqOper(curMtrx[i,2])
            }
            else
                depOper <- depVers <- NULL

            if (havePackage(depPkg, depVers, depOper) == FALSE) {
                ## Broken dependency
                brk <- TRUE
                errMsg <- paste("Package",pkg,"version",vers,
                                "requires package",depPkg)
                if (!is.null(depVers))
                    errMsg <- paste(errMsg,"version",depOper,depVers)
                if (getAllDeps == FALSE) {
                    outErrMsg <- paste(errMsg,", would you like to try ",
                                       "to install this package?",
                                       sep="")
                    ans <- userQuery(outErrMsg,c("yes","no"))
                }
                else
                    ans <- "yes"

                if (ans == "yes") {
                    inOut<- install.packages2(depPkg, repEntry,
                                              lib, getNewest=getNewest,
                                              searchOptions=searchOptions,
                                              getAllDeps=getAllDeps, method=method)
                    updPkgs <- updatedPkgs(inOut)
                    if (length(updPkgs) > 0) {
                        ## Get the proper pkg in the status list
                        ## this should be the last, but just in case:
                        if (depPkg %in% updPkgs) {
                            pkgPos <- match(depPkg, packages(inOut))
                            newDepVers <- getPkgVersion(inOut, pkgPos)
                            ## need to verify version
                            if (!(is.null(depOper))&&!(is.null(depVers))) {
                                if (checkVers(newDepVers,depOper,
                                              depVers) == TRUE) {
                                    brk <- FALSE
                                }
                            }
                            else
                                brk <- FALSE
                        }
                        statusList(retPSlist) <- inOut
                    }
                }
                if (brk == TRUE) {
                    out <- c(out,errMsg)
                    note(paste("Package",depPkg,
                               "not found in any known repository."))
                }
            }
        }
    }

    assign("out",out,retEnv)
    assign("pkgList",retPSlist, retEnv)

    ## Remove this package from the circRef checker
    reposToolsCurrentInstalls <<- reposToolsCurrentInstalls[-cIlen]

    return(retEnv)
}

havePackage <- function(depPkg, depVers, depOper) {
    if (is.installed(depPkg,depVers, verbose=FALSE, depOper))
        return(TRUE)
    else {
        ## check the reposToolsCurrentInstalls list
        pkgNames <- unlist(lapply(reposToolsCurrentInstalls, pkgName))
        if (!is.na(match(depPkg, pkgNames))) {
            ## Package is in the reposToolsCurrentInstalls
            if (is.null(depVers))
                return(TRUE)
            else {
                pkgVers <- lapply(reposToolsCurrentInstalls, pkgVersion)
                if (any(unlist(lapply(pkgVers, checkVers, depOper,
                                      depVers))))
                    return(TRUE)
            }
        }
    }
    return(FALSE)
}


remove.packages2 <- function(pkgs, lib, force=FALSE) {
    if (missing(lib) || is.null(lib)) {
        lib <- reposToolsLibPaths()[1]
        note(paste("argument `lib' is missing: using", lib))
    }
    if (load.locLib(lib) == FALSE) {
        return(FALSE)
    }

    for (pkg in pkgs) {
        if (!is.installed(pkg)) {
            note(paste("Package",pkg,"is not installed"))
            next
        }
        vers <- getPkgVers(pkg, lib)[[1]]
        ## Check to see if removing this package will break any
        ## dependencies.
        rd <- resolve.depends(buildPkgInfo(pkg,vers),NULL,force,
                              libs=lib, forward=FALSE, remove=TRUE)

        if (get("halt",rd) == TRUE)
            stop(paste("Could not remove package",pkg))

        ## Remove R from the local install
        print(paste("Removing package",pkg,"from system ...."))
        remove.packages(pkg, lib)

        options(show.error.messages=FALSE)
        z <- try(.find.package(pkg, lib))
        options(show.error.messages=TRUE)
        if (! inherits(z,"try-error")) {
            warning("Could not remove package",pkg)
            next
        }

        ## Remove this package from the localLibList
        locPkgs <- unlist(lapply(locLibList, Package))
        whichPkg <- which(locPkgs == pkg)
        if (length(whichPkg) != 0)
            locLibList <- locLibList[-whichPkg]
        print("Removal complete")

    }
    save.locLib(locLibList,lib)
}

repositories <- function(recurse=TRUE) {
    repList <- getOptReposList(recurse)
    title <- "Available Repositories: Select By Number, 0 For None"
    repIndex <- menu(repNames(repList),title=title)
    if (repIndex == 0)
        return(NULL)
    repEntry <- getRepEntry(repList, repIndex)
    return(repEntry)
}

install.packages2 <- function(pkgs, repEntry, lib, recurse=TRUE,
                              type, getNewest=TRUE, force=FALSE,
                              syncLocal=TRUE, searchOptions=FALSE,
                              versForce=TRUE, getAllDeps=FALSE,
                              method="auto") {

    if (missing(repEntry) && missing(pkgs)) {
        repEntry <- repositories()
        if (is.null(repEntry))
            stop(paste("No valid repository was chosen.",
                       "\nCan not continue."))
    }

    if (missing(lib))
        lib <- reposToolsLibPaths()[1]

    retVal <- update.packages2(pkgs, repEntry, lib, recurse,
                               type, force=force, syncLocal=syncLocal,
                               versForce=versForce,
                               searchOptions=searchOptions,
                               install=TRUE, update=FALSE,
                               prevRepos=FALSE, getNewest=getNewest,
                               getAllDeps=getAllDeps, method=method)

    return(retVal)
}

download.packages2 <- function(pkgs, repEntry, destDir, recurse=TRUE,
                               type, getNewest=TRUE, searchOptions=FALSE,
                               versForce=TRUE, force=FALSE, method="auto") {
    if (missing(destDir)) {
        note("destDir parameter missing, using current directory")
        destDir <- getwd()
    }

    retVal <- update.packages2(pkgs, repEntry, libs=destDir,
                               recurse=recurse, type=type,
                               searchOptions=searchOptions,
                               versForce=versForce,
                               syncLocal=FALSE, install=FALSE,
                               prevRepos=FALSE, update=FALSE,
                               force=force, method=method)
    return(retVal)
}

update.packages2 <- function(pkgs=NULL, repEntry, libs=reposToolsLibPaths(),
                             recurse=TRUE, type, prevRepos=TRUE,
                             force=FALSE, fileSelect=baseFileSelect,
                             syncLocal=TRUE, versForce=TRUE,
                             searchOptions=FALSE, getNewest=TRUE,
                             install=TRUE, update=TRUE,
                             getAllDeps=FALSE, method="auto") {

    if (missing(libs) || is.null(libs)) {
        libs <- reposToolsLibPaths()
        note(paste("argument `lib' is missing: using", libs))
    }

    if (missing(pkgs))
        pkgs <- NULL

    repList <- new("ReposList", repList=list())
    if (!missing(repEntry)) {
        if (inherits(repEntry,"ReposEntry")) {
            if (repType(repEntry) != "package")
                stop("update.packages2 requires a package repository")
        }
        else {
            stop("Supplied repEntry argument does not point to a valid repository.")
        }

        repList(repList) <- repEntry
        if (recurse == TRUE) {
            repList(repList) <- getSubRepList(repEntry)
        }
        ## See if we're tacking on option based repositories
        if (searchOptions == TRUE) {
            repList(repList) <- getOptReposList(recurse)
        }
        ## If a repository is specified, we don't want to be using
        ## prevRepos
        prevRepos <- FALSE
    }
    else
        repList(repList) <- getOptReposList(recurse)

    ## Double check to make sure there are entries
    if (numReps(repList) == 0)
        stop("No repositories to search")

    if (is.null(pkgs)) {
        if (update==TRUE) {
            ## If we're updating and packages is blank, need
            ## to fill in w/ all that we currently have
            pkgs <- NULL
            for (i in 1:length(libs)) {
                if (load.locLib(libs[i]) == FALSE) {
                    if (syncLocal == TRUE) {
                        syncLocalLibList(libs[i])
                        load.locLib(libs[i])
                    }
                    else {
                        stop("No local library and syncLocal is FALSE")
                    }
                }
                pkgs <- c(pkgs,unlist(lapply(locLibList,Package)))
                closeLocLib()
            }
        }
        else {
            ## In this case they just want to get everything from
            ## the specified repository
            pkgs <- repPkgs(repEntry)
        }
    }

    if (missing(type) || is.null(type)) {
        bioCOpt <- getOption("BioC")
        type <- bioCOpt$reposEntry$type
        if (is.null(type))
            stop("Can not determine default download type")
        else
            note(paste("You did not specify a download type.",
                       " Using a default value of:",type,
                       "\nThis will be fine for almost all users\n"))
    }

    pStatList <- new("pkgStatusList",statusList=list())

    for (lib in libs) {
        if ((load.locLib(lib) == FALSE)&&(install==TRUE)) {
            if(syncLocal == TRUE) {
                note(paste("Couldn't find a local library database in library",lib,".  Synching"))
                syncLocalLibList(lib)
                load.locLib(lib)
            }
            else {
                next
            }
        }

        if (prevRepos == TRUE) {
            ## Now try to download anything that has a prevRepos
            cPRenv <- checkPrevRepos(pkgs, lib, type, versForce,
                                     force, install, searchOptions,
                                     getAllDeps=getAllDeps,
                                     method=method)
            pkgs <- get("newPkgs", cPRenv)
            statusList(pStatList) <- get("cprStatList", cPRenv)
        }

        if (length(pkgs) > 0) {
            ## Retrieve the pkgList object for this download
            pkgList <- buildPkgListing(repList, pkgs, type)

            ## If not found at prevRepos, or prevRepos is false, need to
            ## resolve which option to download
            statusList(pStatList) <- fileSelect(pkgList, lib, type,
                                                getNewest=getNewest,
                                                versForce=versForce, force=force,
                                                install=install,
                                                searchOptions=searchOptions,
                                                getAllDeps=getAllDeps,
                                                method=method)
        }

        closeLocLib()
    }
    return(invisible(pStatList))
}

checkPrevRepos <- function(pkgs, lib, type, versForce, force,
                           install, searchOptions=TRUE,
                           getAllDeps=FALSE, method="auto") {
    ## For every package already installed that is in pkgList
    ## Try to get it from its previous URL

    cprEnv <- new.env()
    newPSList <- list()

    urls <- getLocLibURLs(pkgs, lib)
    if (is.null(urls)) {
        assign("newPkgs", pkgs, cprEnv)
        assign("cprStatList", newPSList, cprEnv)
        return(cprEnv)
    }

    found <- NULL
    whichPkgs <- which(urls != "NA")
    for (whichPkg in whichPkgs) {
        repE <- getReposEntry(urls[whichPkg])
        if (!is.null(repE)) {
            pkg <- pkgs[whichPkg]
            repInfos <- repPkgInfos(repE, pkg, type)
            versions <- lapply(repInfos, pkgVersion)
            maxEle <- getMaxElement(versions)
            maxVers <- pkgVersion(repInfos[[maxEle]])
            if (maxVers > getPkgVers(pkg,lib)[[1]]) {
                ## Need to download/install
                pInf <- buildPkgInfo(pkg, maxVers)
                rd <- resolve.depends(pInf, repE, force,
                                      searchOptions=searchOptions,
                                      getAllDeps=getAllDeps)

                if (get("halt",rd) == FALSE) {
                    fileName <- downloadFile(repE, pkg, stringRep(maxVers),
                                             type, method=method)
                    handleDownloadedFile(fileName, pkg, maxVers, type, lib,
                                         install, versForce, repE)
                    newPSList[[length(newPSList)+1]] <-
                        new("pkgStatus", package=pkg, found=TRUE,
                            updated=TRUE, url=repURL(repE),
                            pkgVersion=maxVers)
                    found <- c(found,whichPkg)
                }
            }
        }
    }

    if (length(found) > 0)
        pkgs <- pkgs[-found]

    assign("newPkgs", pkgs, cprEnv)
    assign("cprStatList", newPSList, cprEnv)
    return(cprEnv)
}

baseFileSelect <- function(pkgList, lib, type, getNewest=TRUE,
                           versForce=TRUE, force=FALSE, install=TRUE,
                           searchOptions=FALSE, getAllDeps=FALSE,
                           method="auto") {

    pkgStats <- new("pkgStatusList",statusList=list())
    Packages <- pkgList(pkgList)
    if (length(Packages) == 0)
        return(pkgStats)
    pkgs <- packages(pkgList)

    ## gotPkgs denotes packages that were acquired as a side effect
    ## of dependency checking.  Some of these might be ones that we
    ## were already looking for, so need to detect this
    gotPkgs <- NULL


    for (i in 1:length(Packages)) {
        if (pkgs[i] %in% gotPkgs)
            next

        ok <- TRUE
        if (getNewest == TRUE) {
            ## Simply find the newest version of each package and
            ## download
            rep <- 1
            index <- 1
            for (repCheck in 1:length(Packages[[i]])) {
                curMax <- buildVersionNumber("0")
                idx <- getMaxElement(Packages[[i]][[rep]])
                if (Packages[[i]][[rep]][[idx]] >= curMax) {
                    index <- idx
                    rep <- repCheck
                }
            }
        }
        else {
            ## Provide a menu selection of the available downloads and
            ## get the one selected in each case
            pvl <- pkgVersionList(pkgList, pkgs[i], "names")
            if (length(pvl) == 0) {
                next()
            }
            choices <- vector()
            repNames <- names(pvl)
            choiceReps <- vector()
            for (curRN in 1:length(pvl)) {
                curPvl <- pvl[[curRN]]
                for (curVer in 1:length(curPvl)) {
                    choiceReps <- c(choiceReps, curRN)
                    choices <- c(choices,
                                 paste(repNames[curRN],
                                       "has version",
                                       stringRep(curPvl[[curVer]])))
                }
            }

            if (length(choices) > 1) {
                title <- paste("\nPlease select (by number) a download ",
                               "site for package ", pkgs[i],":",sep="")
                index <- menu(choices,title=title)
                if (index == 0) {
                    note(paste("Skippping package",pkgs[i]))
                    next()
                }
            }
            else {
                index <- 1
            }
            rep <- choiceReps[index]
        }

        pkg <- pkgs[i]
        pkgVer <- Packages[[i]][[rep]][[index]]

        pkgInfo <- buildPkgInfo(pkg, pkgVer)

        repIndex <- as.numeric(names(Packages[[i]][rep]))
        repEntry <- getRepEntry(pkgList, repIndex)

        curVers <- getPkgVers(pkg,lib)

        ## !! Couldn't get the commented version of the if to work the
        ## !! way I was hoping to, using this as a hack for onw
        if (length(curVers) == 0)
            curVers[[1]] <- buildVersionNumber("0")
##        if ((length(curVers) > 0)||(pkgVer > curVers[[1]])) {

        if (pkgVer > curVers[[1]]) {

            ## Check to see if changing this file will break any
            ## other package's dependencies on it
            rd <- resolve.depends(pkgInfo, repEntry, force,
                                  searchOptions=searchOptions,
                                  getAllDeps=getAllDeps,
                                  versForce=versForce,
                                  getNewest=getNewest)

            rdPkgs <- get("pkgList",rd)
            if (length(packages(rdPkgs)) > 0) {
                gotPkgs <- c(gotPkgs,packages(rdPkgs))
                statusList(pkgStats) <- rdPkgs
            }

            if (get("halt",rd) == TRUE) {
                ok <- FALSE
            }
            else {
                ## Check cur version of file vs. this one

                ## Only need the first ele of returned list here
                ## as we're using just one lib as arg and can't have
                ## multi-installs.
                curPkgVers <- getPkgVers(pkg, lib)
                if (length(curPkgVers) > 0) {
                    if (curPkgVers[[1]] >= pkgVer) {
                        ok <- FALSE
                    }
                }
            }

            if (ok == TRUE) {
                fileName <- downloadFile(repEntry, pkg, stringRep(pkgVer),
                                         type, method=method)

                ret <- handleDownloadedFile(fileName, pkg, pkgVer, type, lib,
                                            install, versForce, repEntry)
            }
            else {
                ret <- FALSE
            }
        }
        else
            ret <- FALSE

        ## Add this package to the pkgStatusList
        statusList(pkgStats) <- new("pkgStatus",package=pkg,
                                    found=TRUE, updated=ret,
                                    url=repURL(repEntry),
                                    pkgVersion=pkgVer)
    }
    return(pkgStats)
}

handleDownloadedFile <- function(fileName, pkg, pkgVer, type, lib,
                                 install, versForce, repEntry) {
    if (is.null(fileName)) {
        warning(paste("No package ",pkg," version ",
                      stringRep(pkgVers)," of type ",type,
                      " exists at ",
                      repURL(repEntry),",skipping",sep=""))
        return(FALSE)
    }

    if (install == TRUE) {

        if (installPkg(fileName, pkg, pkgVer, type, lib, repEntry,
                       versForce)==TRUE) {
            updateLocLib(lib, pkg, pkgVer, repEntry)
        }
    }
    else {
        ## Just copy the file to the real location
        file.copy(fileName,file.path(lib,basename(fileName)),
                  TRUE)
    }
    unlink(fileName)
    return(TRUE)
}

installPkg <- function(fileName, pkg, vers, type, lib, repEntry,
                       versForce=TRUE) {
    if ((!is.null(fileName))&&(file.exists(fileName))) {
        OST <- .Platform$OS.type
        print(paste("Installing",pkg))
        if (type == "Win32") {
            ## Check for version compat)
            Rvers <- getRversion()
            builtVers <- pkgRVersion(repEntry, pkg, vers, type)
            out <- paste("Running R version ",Rvers," and package ",
                         pkg," was built for R version ",
                         builtVers,"\n",sep="")
            if (builtVers < Rvers) {
                if (versForce==FALSE) {
                    out <- paste(out, ", skipping.\nPlease ",
                              "look at the option versForce if you ",
                              "would like to continue.",sep="")
                    warning(out)
                    return(FALSE)
                }
                else {
                    out <- paste(out,", installing anyway.\n")
                    note(out)
                }
            }
            if (OST != "windows") {
                warning(paste("Attempting to install Win32 version of",
                               pkg,"on a",OST,"system, skipping."))
                return(FALSE)
            }
            status <- zip.unpack(fileName, lib)
        }
        else if (type == "Source") {
            if (OST != "unix") {
                warning(paste("Attempting to install Unix version of",
                           pkg,"on a",OST,"system, skipping."))
                return(FALSE)
            }
            cmd <- paste(file.path(R.home(), "bin", "R"),
                         "CMD INSTALL -l", lib, fileName)
            status <- system(cmd)
        }
        else {
            warning(paste("Do not know how to install packages of type",
                          " ",type,", skipping.",sep=""))
            return(FALSE)
        }

        if (status != 0) {
            warning(paste("Installation of package", pkg,
                          "had non-zero exit status"))
        }
        else {
            print("Installation complete")
        }
    }
    return(TRUE)
}

getOptReposList <- function(recurse=TRUE) {
    ## Takes the option "repositories" and returns a list of
    ## reposEntry objects from those entries.
    reps <- as.character(getReposOption())
    if (length(reps) > 0) {
        repL <- lapply(reps,getReposEntry)
        ## remove NULL entries
        repL <- repL[!sapply(repL,is.null)]
        return(getReposList(repL, recurse))
    }
    else {
        return(NULL)
    }
}

reposToolsLibPaths <- function(baseLib=.libPaths(),
                               tmpLibPath=file.path(tempdir(),"tempLibs")) {
    ## Will add any temporarily maintained liblisting.Rda files to
    ## the search path
    newDirs <- character()

    if ((file.exists(tmpLibPath))&&(file.info(tmpLibPath)$isdir)) {
        newDirs <- dir(tmpLibPath, full.names=TRUE)
        if (length(newDirs) > 0) {

            ## Filter out any that aren't actually directories as these are
            ## obviously garbage
            areDirs <- unlist(lapply(lapply(newDirs,file.info),function(x){return(x$isdir)}))
            newDirs <- newDirs[areDirs]
        }
    }

    return(c(baseLib, newDirs))
}
