buildPkgDepGraph <- function(pkg, repEntry, type,
                             curNodes=vector(mode="character")) {
    ## Given a repository will look first to see what packages it
    ## depends on, and what packages *those* depend on and so on,
    ## generating a complete dependency graph

    require("graph") || stop("buildPkgDepGraph needs package 'graph'")

    ## Create the 'root' of this graph
    dGraph <- new("graphNEL", nodes=pkg, edgemode="directed")


    if (length(pkg) != 1) {
        warning("pkg argument must be of length one")
        return(dGraph)
    }

    curRepList <- new("ReposList", repList=list())

    if (missing(type) || is.null(type)) {
        bioCOpt <- getOption("BioC")
        type <- bioCOpt$reposEntry$type
        if (is.null(type)) {
            warning("Can not determine package type")
            return(dGraph)
        }
    }

    if (!missing(repEntry)) {
        if (!inherits(repEntry,"ReposEntry")) {
            warning("Supplied repEntry argument is not a ReposEntry object")
            return(dGraph)
        }
        repList(curRepList) <- repEntry
        repList(curRepList) <- getSubRepList(repEntry)
    }
    else
        repList(curRepList) <- getOptReposList()

    curPkgList <- buildPkgListing(curRepList, pkg, type)
    Packages <- pkgList(curPkgList)
    if (length(Packages) == 0) {
        note(paste("Package",pkg,"not found in any online repositories"))
        return(dGraph)
    }

    rep <- 1
    index <- 1
    for (i in 1:length(Packages[[1]])) {
        curMax <- buildVersionNumber("0")
        idx <- getMaxElement(Packages[[1]][[rep]])
        if (Packages[[1]][[rep]][[idx]] >= curMax) {
            index <- idx
            rep <- i
        }
    }

    pkgVer <- Packages[[1]][[rep]][[index]]
    curPkgInfo <- buildPkgInfo(pkg, pkgVer)
    repIndex <- as.numeric(names(Packages[[1]][rep]))
    repEntry <- getRepEntry(curPkgList, repIndex)

    ## Get dependencies for this package, adding each one to the graph
    depMtrx <- getDepMtrx(depends(repEntry, curPkgInfo))

    for (i in seq(along=depMtrx[,1])) {
        depPkg <- depMtrx[i,1]
        if (depPkg == "R")
            next

        ## recursively call buildPkgDepGraph and take it's dGraph
        ## return and 'join' it with this graph, then create an
        ## edge between it's 'root' and this package
        newCurNodes <- unique(c(curNodes, nodes(dGraph)))

        if (!depPkg %in% curNodes) {
            newGraph <- buildPkgDepGraph(depPkg, curNodes=newCurNodes)
            dGraph <- join(dGraph, newGraph)
        }
        else {
            ## If the package is not in curnodes nor in the
            ## current graph, it represents a circular reference
            ## and the node needs to be in the current graph.
            ## If the node is in currnodes but already in the
            ## graph, it is simply a duplicate entry.
            if (!depPkg %in% nodes(dGraph))
                dGraph <- addNode(depPkg, dGraph)
        }

        dGraph <- addEdge(depPkg, pkgName(curPkgInfo), dGraph, 1)
        curNodes <- newCurNodes
    }
    dGraph
}
