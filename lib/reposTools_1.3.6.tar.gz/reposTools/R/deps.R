load.depends <- function(x,suggests=TRUE,uses=TRUE,Rversion=TRUE) {
    depList <- getObjectDeps(x)
    if (length(depList) == 0)
        return()
    else {
        if (!is.null(depList$Depends))
            check.depends(x, getDepMtrx(depList$Depends),failRDep=Rversion)
        if (!is.null(depList$Suggests))
            check.depends(x, getDepMtrx(depList$Suggests),failPkgDep=suggests,
                          failRDep=Rversion)
        if (!is.null(depList$Uses))
            check.depends(x, getDepMtrx(depList$Uses),failPkgDep=uses,
                          failRDep=Rversion)
    }
}

unresolved.depends <- function(x,suggests=TRUE,uses=TRUE,Rversion=TRUE) {
    depList <- getObjectDeps(x,suggests,uses)
    outList <- list()
    if (length(depList) == 0)
        return()
    else {
        if (!is.null(depList$Depends)) {
            deps <- check.depends(x, getDepMtrx(depList$Depends),
                                  failRDep=Rversion, load=FALSE)
            if (length(deps) > 0)
                outList$Depends <- deps
        }
        if (!is.null(depList$Suggests)) {
            sugs<- check.depends(x, getDepMtrx(depList$Suggests), load=FALSE,
                                 failPkgDep=suggests,failRDep=Rversion)
            if (length(sugs) > 0)
                outList$Suggests <- sugs
        }
        if (!is.null(depList$Uses)) {
            uses <- check.depends(x, getDepMtrx(depList$Uses),
                                  failPkgDep=uses, load=FALSE,
                                  failRDep=Rversion)
            if (length(uses) > 0)
                outList$Uses <- uses
        }
    }
    return(outList)
}

check.depends <- function(x, depMtrx, failPkgDep=TRUE,failRDep=TRUE,
                          load=TRUE) {
    outLine <- vector()
    for (i in 1:nrow(depMtrx)) {
        if (depMtrx[i,1] == "R") {
            ## If the R version doesn't match the requested dependency
            ## stop the function w/ an error
            ret <- checkRVersion(x,depMtrx[i,,drop=FALSE])
            if (ret == FALSE) {
                outLine <- c(outLine,paste(depMtrx[i,1]," (",
                                           depMtrx[i,2],")",sep=""))
                if (load == TRUE) {
                    outString <- paste(" package ",x," requires R version ",
                                       getReqVers(depMtrx[i,2]),
                                       ".  Please see http://http://cran.r-project.org/ for information on how to get the proper version.", sep="")
                    if (failRDep == TRUE) {
                        stop(paste("Can not continue:",outString))
                    }
                    else {
                        warning(outString)
                    }
                }
            }
        }
        else {
            outString <- paste("Package",x,"requires version",
                               depMtrx[i,2],
                               "of package",depMtrx[i,1],
                               ", which is not currently installed.",
                               "Please see help(\"install.packages2\")",
                               "for instructions on how to install",
                               "this package")
            if (depMtrx[i,2] != "") {
                ## need to check pkg version
                pkgVers <- getPkgVers(x,verbose=FALSE)
                rets <- lapply(pkgVers,checkVers,
                               getReqOper(depMtrx[i,2]),
                               getReqVers(depMtrx[i,2]))
                if (!any(unlist(rets))) {
                    outLine <- c(outLine,paste(depMtrx[i,1]," (",
                                               depMtrx[i,2],")",sep=""))
                    if (load == TRUE) {
                        if (failPkgDep == TRUE)
                            stop(paste("Can not continue:",outString))
                        else
                            warning(outString)
                    }
                }
            }
            if (load == TRUE) {
                ## !!!! If requiring a version, should eventually make
                ## !! sure we are getting the proper one.  'require'
                ## !! does not yet
                ## !! handles this.  In the shorter term, should get the highest
                ## !! version that matches criterion if there are multiples
                curWarn <- getOption("warn")
                options(warn = -1)
                on.exit(options(warn=curWarn),add=TRUE)
                ret <- do.call("require",list(depMtrx[i,1]))
                options(warn=curWarn)
                if (!ret) {
                    if (failPkgDep == TRUE)
                        stop(paste("Can not continue:",outString))
                    else
                        warning(outString)
                }
            }
            else {
                ## Only need to check to see if the pkg is installed

                if (!is.installed(depMtrx[i,1],verbose=FALSE))
                    outLine <- c(outLine,paste(depMtrx[i,1]))
            }
        }
    }
    invisible(outLine)
    return(outLine)
}

checkRVersion <- function(x,depMtrx) {
    ## Passed a row of a dependency matrix, will check to see if the R
    ## version is a dependency, and if so if the current R version is
    ## acceptable.  Returns TRUE if either the R version is fine or
    ## this row does not correspond to a R dependency, and FALSE if it
    ## does and the version is not correct
    if (depMtrx[1,1] == "R") {
        if (depMtrx[1,2] != "") {
            ## need to check R version
            rVers <- getRversion()
            ret <- checkVers(rVers,getReqOper(depMtrx[1,2]),
                             getReqVers(depMtrx[1,2]))
            if (ret == FALSE)
                return(FALSE)
        }
    }
    return(TRUE)
}

getVigDeps <- function(x,suggests=TRUE,uses=TRUE) {
    if (!file.exists(x))
        stop(paste("Vignette file",x,"not found."))

    vigList <- getVigInfo(x)
    depList <- list()
    vigDeps <- vigList$VignetteDepends
    if (!is.na(vigDeps))
        depList$Depends <- vigDeps

    if (suggests) {
        vigSugs <- vigList$VignetteSuggests
        if (!is.na(vigSugs))
            depList$Suggests <- vigSugs
    }

    if(uses) {
        vigUses <- vigList$VignetteUses
        if (!is.na(vigUses))
            depList$Uses <- vigUses
    }

    return(depList)
}

getObjectDeps <- function(x,suggests=TRUE,uses=TRUE) {
    ## First determien if x is a package or vignette
    if (length(grep("\\.(Rnw|Snw|rnw|snw)$",x)) == 0)
        depList <- getPkgDeps(x,suggests,uses)
    else
        depList <- getVigDeps(x,suggests,uses)
    if (length(depList) == 0)
        return()

    return(depList)
}

getPkgDeps <- function(x,suggests=TRUE,uses=TRUE) {
    depList <- list()
    if (!is.na(desc <- package.description(x,fields="Depends")))
        depList$Depends <- strsplit(desc,",[[:space:]]*")[[1]]

    if(suggests==TRUE) {
        if (!is.na(sugs <- package.description(x,fields="Suggests"))) {
            sugs <- strsplit(sugs,",[[:space:]]*")[[1]]
            depList$Suggests <- sugs
        }
    }

    if (uses==TRUE) {
        if (!is.na(use <- package.description(x,fields="Uses"))) {
            use <- strsplit(use,",[[:space:]]*")[[1]]
            depList$Uses <- use
        }
    }
    return(depList)
}

getDepMtrx <- function(deps) {
    ## Takes in a vector of dependencies, separates any version
    ## requirements.  Returns a matrix, col1 is the packs, col2
    ## is any algebraic requirements
    if ((is.null(deps))||(length(deps)==0)||(deps==""))
        return(NULL)

    tmp <- strsplit(deps,",")
    if (!is.null(tmp))
        deps <- unlist(tmp)

    deps <- gsub("\\)","",deps)
    deps <- strsplit(deps,"\\(")
    ## Now have a list, some w/ 1 els some w/ more (those w/ reqs)
    deps <- lapply(deps, function(x){
                             if (length(x) == 1)
                                 return(c(x, ""))
                             else
                                 return(x)
                         }
                   )
    pkgs <- lapply(deps,function(x){return(x[1])})
    reqs <- lapply(deps,function(x){return(x[2])})
    depMtrx <- cbind(matrix(unlist(pkgs)),matrix(unlist(reqs)))
    ## Kill any trailing whitespace on entries
    for (i in 1:2)
        depMtrx[,i] <- gsub("[[:space:]]$","",depMtrx[,i])

    if (depMtrx[1,1] == "NA")
        depMtrx <- NULL

    return(depMtrx)
}


getReqVers <- function(depReq) {
    return(buildVersionNumber(gsub("(>)|(<)|(=)|([[:space:]])","",depReq)))
}

getReqOper <- function(depReq) {
    return(gsub("[^><=]","",depReq))
}





