getReposOption <- function() {
    out <- getOption("repositories2")
    out
}

getMangledName <- function(pkg, vers, mangSep=":v:") {
    if (inherits(vers,"VersionNumber"))
        vers <- stringRep(vers)
    return(paste(pkg,mangSep,vers,sep=""))
}

getReposEntry <- function(repURL, repFile="replisting",
                          rddFile="repdatadesc.rda") {
    ## First check to see if repURL is symbolic
    optReps <- getReposOption()
    if (repURL %in% names(optReps))
        repURL <- as.character(optReps[repURL])

    ## Get the replisting from the remote repository
    repListing <- getReplisting(repURL, repFile)
    if (is.null(repListing)) {
        note(paste(repURL,
                   "does not seem to have a valid repository, skipping"))
        return(NULL)
    }
    repDf <- loadRepDD(repURL, rddFile)
    ## repDf is supposed to be able to be NULL, but need something of
    ## class 'data.frame' for the reposEntry object.
    if (is.null(repDf))
        repDf <- data.frame()
    repDf <- new("repdatadesc", repdatadesc=repDf)
    return(buildReposEntry(repListing, repDf))
}

getReplisting <- function(repURL,repFile="replisting") {
    ## Passed a repository URL, will retrieve the replisting (if any)
    fileURL <- paste(repURL, repFile, sep="/")
    options(show.error.messages = FALSE)
    on.exit(options(show.error.messages = TRUE))
    repCon <- try(url(fileURL))
    if (inherits(repCon,"try-error") == TRUE) {
        warning(paste("Failed to read replisting at",
                      repURL))
        return(NULL)
    }
    on.exit(close(repCon),add=TRUE)
    tryRes <- try(read.dcf(file=repCon))
    options(show.error.messages=TRUE)
    if (inherits(tryRes,"try-error") == TRUE) {
        return(NULL)
    }
    if (length(tryRes) == 0) {
        warning("Empty replisting file at ", repURL)
        return(NULL)
    }

    repL <- new("replisting", replisting=tryRes)
    return(repL)
}

loadRepDD <- function(repURL, repDD="repdatadesc.rda") {
    ## Will load the remote repository's repdatadesc RDA file, if
    ## available
    ddURL <- paste(repURL,repDD,sep="/")

    options(show.error.messages=FALSE)
    retVal <- try(loadURL(ddURL, quiet=TRUE, mode="wb"))
    options(show.error.messages=TRUE)

    if (inherits(retVal, "try-error")) {
        warning(paste("Failed to read repdatadesc at",
                      repURL))
        return(NULL)
    }

    return(reposDF)
}

    setClass("replisting", representation(replisting="matrix"))


    if (is.null(getGeneric("replisting")))
        setGeneric("replisting", function(object)
                   standardGeneric("replisting"))

    if (is.null(getGeneric("repURL")))
        setGeneric("repURL", function(object, pos)
                   standardGeneric("repURL"))

    setMethod("summary","replisting",function(object, ...) {
        repL <- replisting(object)
        rem <- nrow(repL)-1
        repL <- repL[1,,drop=FALSE]
        print.matrix(repL,quote=FALSE,collab=c("Repository Name   ",
                                      "Repository Type   ","Repository Base URL   ",
                                      "Repository URL Path"),
                     rowlab=paste(as.character(1:nrow(repL)),":",sep=""))
        if (rem > 1) {
            print.noquote(paste(rem,"other repositories known.  Use verbose=TRUE to see their information"))
        }
    })


    setMethod("show","replisting",function(object) {
        rL <- replisting(object)
        nreps <- nrow(rL)
        cat("Repository Listing:\n")
        for(i in seq(along=nreps)) {
            cat("\tRepository: ", rL[i, "repname"], "\n")
            cat("\t\t Type: ", rL[i, "reptype"], "\n")
        }
        return(NULL)})


    setMethod("replisting", "replisting", function(object)
              object@replisting)

    setMethod("repURL","replisting",
              function(object, pos) {
                  if (missing(pos))
                      pos <- 1
                  base <- object@replisting[pos,"repaddrBase"]
                  path <- object@replisting[pos,"repaddrPath"]

                  reps <- getReposOption()
                  if (!is.na(reps[base]))
                      base <- as.character(reps[base])

                  url <- paste(base, path, sep="/")
                  return(url)
              })

    if (is.null(getGeneric("numSubReps")))
        setGeneric("numSubReps", function(object)
                   standardGeneric("numSubReps"))
    setMethod("numSubReps", "replisting", function(object)
              (nrow(object@replisting)-1))

    setClass("repdatadesc", representation(repdatadesc="data.frame"))

if (is.null(getGeneric("repdatadesc")))
    setGeneric("repdatadesc", function(object)
               standardGeneric("repdatadesc"))

    setMethod("repdatadesc", "repdatadesc", function(object)
              object@repdatadesc)
    setMethod("summary","repdatadesc",function(object, ...) {
            repD <- repdatadesc(object)
            print(noquote(paste(as.character(nrow(repD)),"packages available")))
        })

    if (is.null(getGeneric("depends")))
        setGeneric("depends", function(object, pkgInfo)
            standardGeneric("depends"))
    setMethod("depends","repdatadesc",function(object, pkgInfo){
        mangName <- getMangledName(pkgName(pkgInfo), pkgVersion(pkgInfo))
        if (mangName %in% rownames(object@repdatadesc)) {
            out <- object@repdatadesc[mangName,]$Depends[[1]]
            out
        }
        else
            return(NULL)
    })

    if (is.null(getGeneric("suggests")))
        setGeneric("suggests", function(object, pkgInfo)
            standardGeneric("suggests"))
    setMethod("suggests","repdatadesc",function(object, pkgInfo){
        mangName <- getMangledName(pkgName(pkgInfo), pkgVersion(pkgInfo))
        if (mangName %in% rownames(object@repdatadesc)) {
            out <- object@repdatadesc[mangName,]$Suggests[[1]]
            out
        }
        else
            return(NULL)
    })

    if (is.null(getGeneric("uses")))
        setGeneric("uses", function(object, pkgInfo)
            standardGeneric("uses"))
    setMethod("uses","repdatadesc",function(object, pkgInfo){
        mangName <- getMangledName(pkgName(pkgInfo), pkgVersion(pkgInfo))
        if (mangName %in% rownames(object@repdatadesc)) {
            out <- object@repdatadesc[mangName,]$Uses[[1]]
            out
        }
        else
            return(NULL)
    })

    if (is.null(getGeneric("keywords")))
        setGeneric("keywords", function(object, pkgInfo)
            standardGeneric("keywords"))
    setMethod("keywords","repdatadesc",function(object, pkgInfo){
        mangName <- getMangledName(pkgName(pkgInfo), pkgVersion(pkgInfo))
        if (mangName %in% rownames(object@repdatadesc)) {
            out <- object@repdatadesc[mangName,]$Keywords[[1]]
            out
        }
        else
            return(NULL)
    })

    setMethod("show","repdatadesc",function(object) {
        repD <- repdatadesc(object)
        if (inherits(repD,"Pkg")) {
            pkgs <- repD$Package
            vers <- unlist(lapply(repD$Version,as.character))
            OSspec <- repD$OSspecific
            types <- unlist(lapply(lapply(OSspec,names),paste,collapse=", "))
            mat <- t(rbind(pkgs,vers,types))
            print.matrix(mat,quote=FALSE,collab=c("Package   ",
                                         "Version    ","Types Available"),
                         rowlab=paste(as.character(1:nrow(repD)),":",sep=""))
        }
        else if (inherits(repD,"Vignette")) {
            vigs <- repD$VignetteIndexEntry
            vigMtrx <- matrix(vigs)
            print.matrix(vigMtrx,quote=FALSE,
                         collab=c("Vignette Name"),
                         rowlab=paste(as.character(1:nrow(repD)),":",sep=""))
        }
    })


    setClass("pkgListing", representation(pkgList="list",
                                          repList="ReposList"))

    if (is.null(getGeneric("pkgList")))
        setGeneric("pkgList", function(object)
                   standardGeneric("pkgList"))
    setMethod("pkgList", "pkgListing", function(object)
              object@pkgList)

    if (is.null(getGeneric("repList")))
        setGeneric("repList", function(object)
                   standardGeneric("repList"))
    setMethod("repList", "pkgListing", function(object)
              object@repList)

    if (is.null(getGeneric("repListing")))
        setGeneric("repListing", function(object)
                   standardGeneric("repListing"))
    setMethod("repListing", "pkgListing", function(object)
              repList(object@repList))

    if (is.null(getGeneric("getRepEntry")))
        setGeneric("getRepEntry", function(object, pos)
                   standardGeneric("getRepEntry"))
    setMethod("getRepEntry", "pkgListing", function(object, pos)
              getRepEntry(object@repList,pos))

    if (is.null(getGeneric("packages")))
        setGeneric("packages", function(object)
                   standardGeneric("packages"))
    setMethod("packages", "pkgListing", function(object)
              names(object@pkgList))

    if (is.null(getGeneric("downloadRepFile")))
        setGeneric("downloadRepFile", function(object, pos, file, vers, type,
                                               dest=NULL)
                   standardGeneric("downloadRepFile"))
    setMethod("downloadRepFile", "pkgListing", function(object, pos,
                                                        file, vers,
                                                        type,
                                                        dest=NULL) {
        z <- downloadRepFile(object@repList, pos, file, vers, type,
                             dest)
        z
    })



    if (is.null(getGeneric("pkgVersionList")))
        setGeneric("pkgVersionList", function(object, pkg, names)
                   standardGeneric("pkgVersionList"))
    setMethod("pkgVersionList", "pkgListing", function(object, pkg,
                                                       names) {
        if (missing(names))
            names <- "index"

        pList <- object@pkgList[[pkg]]
        if (length(pList) == 0)
            return(pList)

        curNames <-  names(pList)
        names(pList) <- switch(names,
                              "names"=repNames(repList(object),as.numeric(curNames)),
                              "urls"=repURLs(repList(object),as.numeric(curNames)),
                              "index"=curNames,
                               stop(paste(names,
                                          "is not valid for option names:",
                                          "please choose between\n 'names',",
                                          "'urls', and 'index'."))
                               )
        pList
    })


    setMethod("summary","pkgListing",function(object, ...){
        cat("A package listing with the following packages:\n")
        print(packages(object))
        cat("\nFrom:\n")
        show(repList(object))
    })

    setMethod("show","pkgListing",function(object) {
        pL <- pkgList(object)
        if (length(pL) == 0)
            return(NULL)
        out <- matrix(ncol=3)
        pkgs <- names(pL)
        for (i in 1:length(pL)) {
            if (length(pL[[i]]) > 0) {
                whichREs <- as.numeric(names(pL[[i]]))
                outURLs <- repURLs(repList(object), whichREs)
                for (j in 1:length(pL[[i]])) {
                    if (length(pL[[i]][[j]]) > 0) {
                        for (k in 1:length(pL[[i]][[j]])) {
                            out <- rbind(out,c(pkgs[i],
                                               stringRep(pL[[i]][[j]][[k]]),
                                               outURLs[j]))
                        }
                    }
                }
            }
        }
        print.matrix(out[2:nrow(out),,drop=FALSE],quote=FALSE,
                     collab=c("Package   ", "Version   ","Repository URL"),
                     rowlab=paste(as.character(1:nrow(out)),":",sep=""))
    })

buildPkgListing <- function(repList, pkgs=NULL, type=NULL) {
    if (!(inherits(repList,"ReposList")) && (is.list(repList)))
        repList <- buildReposList(repList)

    if (!inherits(repList,"ReposList"))
        return(NULL)

    ## pkgs==NULL implies "all packages"
    if (numReps(repList)<1)
        return(NULL)

    if (is.null(pkgs)) {
        pkgs <- repPkgs(repList)
        if (is.null(pkgs))
            return(NULL)
    }

    ## We can have either a vector of pkg names, a list of pkg names,
    ## or a list of pkgInfos.  In any case, make sure that we have a
    ## vector of pkg names
    if (is.list(pkgs)) {
        pkgs <- lapply(pkgs, function(x) {
            if (is(x,"pkgInfo"))
                return(pkgName(x))
            else if (is.character(x))
                return(x)
            else
                stop("Malforemd 'pkgs' parameter")
        })
    }

    ## Create skeleton for pkgList
    pkgList <- vector(mode="list",length=length(pkgs))
    names(pkgList) <- pkgs
    for (i in 1:length(pkgList))
        pkgList[[i]] <- list()

    ## Now for each repository, get any appropriate pkg info
    repPIs <- repPkgInfoList(repList, pkgs, type)

    ## !! There has to be a better way here then a double for loop
    for (j in 1:numReps(repList)) {
        if (!is.null(repPIs[[j]])) {
            pkgN <- unlist(lapply(repPIs[[j]],pkgName))
            pkgV <- lapply(repPIs[[j]],pkgVersion)
            for (k in which(pkgs %in% pkgN)) {
                len <- length(pkgList[[k]])
                pkgList[[k]][[len+1]] <- pkgV[pkgN == pkgs[k]]
                names(pkgList[[k]])[len+1] <- as.character(j)
            }
        }
    }

    pkgList <- pkgList[sapply(pkgList,
                              function(x){if (length(x) > 0){
                                  TRUE
                              }
                              else {
                                  FALSE
                              }})]
    return(new("pkgListing",pkgList=pkgList,repList=repList))
}

    setClass("ReposList", representation(repList="list"))

    if (is.null(getGeneric("repList")))
        setGeneric("repList", function(object)
                   standardGeneric("repList"))
    setMethod("repList", "ReposList", function(object)
              object@repList)

    if (is.null(getGeneric("repList<-")))
        setGeneric("repList<-", function(object, value)
                   standardGeneric("repList<-"))
    setMethod("repList<-", "ReposList", function(object, value) {
        curURLs <- repURLs(object)
        if (inherits(value,"ReposList")) {
            newURLs <- repURLs(value)
            goodURLs <- which(!(newURLs %in% curURLs))
            if (length(goodURLs) > 0) {
                newList <- repList(value)
                object@repList <- c(object@repList,newList[goodURLs])
            }
        }
        else if (inherits(value,"ReposEntry")){
            if (!(repURL(value) %in% curURLs))
                object@repList[[length(object@repList)+1]] <- value
        }
        else if (is.list(value)){
            newURLs <- repURLs(value)
            goodURLs <- which(!(newURLs %in% curURLs))
            if (length(goodURLs) > 0) {
                object@repList <- c(object@repList,value[goodURLs])
            }
        }
        object
    })

    if (is.null(getGeneric("numReps")))
        setGeneric("numReps", function(object)
                   standardGeneric("numReps"))
    setMethod("numReps", "ReposList", function(object)
              length(object@repList))

    if (is.null(getGeneric("getRepEntry")))
        setGeneric("getRepEntry", function(object, pos)
                   standardGeneric("getRepEntry"))
    setMethod("getRepEntry", "ReposList", function(object, pos)
              object@repList[[pos]])

    if (is.null(getGeneric("repPkgs")))
        setGeneric("repPkgs", function(object)
                   standardGeneric("repPkgs"))
    setMethod("repPkgs", "ReposList", function(object) {
        unique(unlist(lapply(repList(object), repPkgs)))
    })

    if (is.null(getGeneric("repPkgInfoList")))
        setGeneric("repPkgInfoList", function(object, pkgs, type)
                   standardGeneric("repPkgInfoList"))

    setMethod("repPkgInfoList", "ReposList", function(object,pkgs,type) {
        if (missing(type))
            type <- NULL
        if (missing(pkgs))
            pkgs <- NULL
        x <- lapply(repList(object),repPkgInfos,pkgs,type)
        x
    })

    if (is.null(getGeneric("repNames")))
        setGeneric("repNames", function(object,which)
            standardGeneric("repNames"))
    setMethod("repNames", "ReposList", function(object,which) {
        x <- unlist(lapply(repList(object), repName))
        if (!missing(which))
            x <- x[which]
        x
    })

    if (is.null(getGeneric("repURLs")))
        setGeneric("repURLs", function(object,which)
            standardGeneric("repURLs"))
    setMethod("repURLs", "ReposList", function(object,which) {
        x <- unlist(lapply(repList(object), repURL))
        if (!missing(which))
            x <- x[which]
        x
    })

    if (is.null(getGeneric("downloadRepFile")))
        setGeneric("downloadRepFile", function(object, pos, file, vers, type,
                                               dest=NULL)
                   standardGeneric("downloadRepFile"))

    setMethod("downloadRepFile", "ReposList", function(object, pos, file,
                                                    vers, type, dest=NULL){
        z <- downloadFile(object@repList[[pos]], file, vers, type,
                                                    dest)
        z
    })


    setMethod("show", "ReposList", function(object)
              print(paste("A ReposList with",numReps(object),
                          "repositories")))

buildReposList <- function(reps, recurse=TRUE) {
    repList <- getReposList(reps, recurse=TRUE)
    return(new("ReposList",repList=repList))
}

getReposList <- function(reps, recurse=TRUE) {
    ## Will generate a ReposList object out of a set of reposiotires
    outList <- new("ReposList", repList=list())
    if (inherits(reps,"ReposList"))
        reps <- repList(reps)

    for (rep in reps) {
        if (hasFiles(rep))
            repList(outList) <- rep
        if (recurse == TRUE) {
            subs <- numSubReps(rep)
            if (subs > 0)
                repList(outList) <- getReposList(getSubRepList(rep),
                                                 recurse)
        }
    }
    return(outList)
}


    setClass("ReposEntry",representation(replisting="replisting",
                                         repdatadesc="repdatadesc"))

    if (is.null(getGeneric("replisting")))
        setGeneric("replisting", function(object)
                   standardGeneric("replisting"))

    if (is.null(getGeneric("repdatadesc")))
        setGeneric("repdatadesc", function(object)
                   standardGeneric("repdatadesc"))
    if (is.null(getGeneric("repURL")))
        setGeneric("repURL", function(object,pos)
            standardGeneric("repURL"))

    if (is.null(getGeneric("repType")))
        setGeneric("repType", function(object)
                   standardGeneric("repType"))
    if (is.null(getGeneric("repName")))
        setGeneric("repName", function(object)
                   standardGeneric("repName"))

    ################
    ## Basic slot gets, and info straight from replisting
    ################

    setMethod("repType", "ReposEntry", function(object)
              (object@replisting)@replisting[1,"reptype"])

    setMethod("replisting", "ReposEntry", function(object)
              object@replisting)
    setMethod("repdatadesc", "ReposEntry", function(object)
              object@repdatadesc)

    setMethod("repName", "ReposEntry", function(object)
              object@replisting@replisting[1,"repname"])

    setMethod("repURL", "ReposEntry", function(object,pos) {
        if (missing(pos))
            pos <- 1
        repURL(replisting(object),pos)
        })

    setGeneric("repdataframe", function(object)
         standardGeneric("repdataframe"))

    setMethod("repdataframe", "ReposEntry", function(object)
        repdatadesc(repdatadesc(object)))

    ####################
    ####################

    ############
    ## Subrepository management
    ############
    if(is.null(getGeneric("numSubReps")))
        setGeneric("numSubReps", function(object)
                   standardGeneric("numSubReps"))
    setMethod("numSubReps", "ReposEntry", function(object)
              numSubReps(replisting(object)))

    if(is.null(getGeneric("getSubRep")))
        setGeneric("getSubRep", function(object,pos)
                   standardGeneric("getSubRep"))
    setMethod("getSubRep", "ReposEntry", function(object,pos) {
        if (pos > numSubReps(object))
            return(NULL)
        else
            return(getReposEntry(repURL(object,pos+1)))
        })
    if (is.null(getGeneric("getSubRepList")))
        setGeneric("getSubRepList", function(object)
                   standardGeneric("getSubRepList"))
    setMethod("getSubRepList", "ReposEntry", function(object) {
        num <- numSubReps(object)
        out <- list()
        if (num > 0) {
            for (i in 1:num) {
                out[[length(out)+1]] <-
                    getReposEntry(repURL(object,i+1))
            }
        }
        outObj <- new("ReposList",repList=out)
        return(outObj)
    })
    #####################
    #####################

    #####################
    ## Dataframe information
    ######################
        if (is.null(getGeneric("depends")))
        setGeneric("depends", function(object, pkgInfo)
            standardGeneric("depends"))
    setMethod("depends","ReposEntry",function(object, pkgInfo){
        out <- depends(object@repdatadesc, pkgInfo)
        out
    })

    if (is.null(getGeneric("suggests")))
        setGeneric("suggests", function(object, pkgInfo)
            standardGeneric("suggests"))
    setMethod("suggests","ReposEntry",function(object, pkgInfo){
        out <- suggests(object@repdatadesc, pkgInfo)
        out
    })

    if (is.null(getGeneric("uses")))
        setGeneric("uses", function(object, pkgInfo)
            standardGeneric("uses"))
    setMethod("uses","ReposEntry",function(object, pkgInfo){
         out <- uses(object@repdatadesc, pkgInfo)
        out
    })

    if (is.null(getGeneric("keywords")))
        setGeneric("keywords", function(object, pkgInfo)
            standardGeneric("keywords"))
    setMethod("keywords","ReposEntry",function(object, pkgInfo){
         out <- keywords(object@repdatadesc, pkgInfo)
         out
     })

    ######################
    ## Methods to for file manipulation & file information
    ######################
    if(is.null(getGeneric("hasFiles")))
        setGeneric("hasFiles", function(object)
                   standardGeneric("hasFiles"))
    ## hasFiles will determine if the repository has any files for download
    setMethod("hasFiles","ReposEntry", function(object) {
        if (nrow(repdataframe(object)) < 1)
            return(FALSE)
        else
            return(TRUE)
    })

    if (is.null(getGeneric("pkgRVersion")))
        setGeneric("pkgRVersion", function(object, pkg, vers, type)
                   standardGeneric("pkgRVersion"))
    setMethod("pkgRVersion", "ReposEntry", function(object, pkg, vers,
                                                    type)
          {
              z <- repdataframe(object)
              rowN <- getMangledName(pkg, vers)
              if (rowN %in% rownames(z)) {
                  os <- z[rowN,]$OSspecific[[1]][[type]]$Rvers
                  if ((is.null(os))||(os==""))
                      return(NULL)
                  else
                      return(buildVersionNumber(os))
              }
              else
                  return(NULL)
          })

    if (is.null(getGeneric("repPkgs")))
        setGeneric("repPkgs", function(object)
                   standardGeneric("repPkgs"))
    setMethod("repPkgs", "ReposEntry", function(object) {
        repD <- repdataframe(object)
        repD$Package
    })

    if( is.null(getGeneric("repObjects")))
        setGeneric("repObjects", function(object,pkgs,type,files)
            standardGeneric("repObjects"))
    setMethod("repObjects", "ReposEntry", function(object,pkgs=NULL,
                                                   type,files){
	repD <- repdataframe(object)
        if (nrow(repD) == 0)
            return(NULL)
        if (missing(pkgs))
            pkgs <- NULL
        if (!is.null(pkgs))
            whichPkgs <- which(repD$Package %in% pkgs)
        else
            whichPkgs <- 1:nrow(repD)

        if (length(whichPkgs) > 0) {
            repD <- repD[whichPkgs,,drop=FALSE]

            pkg <- repD$Package
            vers <- unlist(lapply(repD$Version,as.character))
            mat <- t(rbind(pkg,vers))
            if ((!missing(type))&&(!is.null(type))) {
                OSspec <- repD$OSspecific
                types <-
                    unlist(lapply(lapply(OSspec,names),paste,collapse=", "))
                types <- strsplit(types,", ")
                rightType <- NULL
                for (i in 1:length(types)) {
                    if (type %in% types[[i]])
                        rightType <- c(rightType,i)
                }
                mat <- mat[rightType,,drop=FALSE]
                if (nrow(mat) == 0)
                    mat <- NULL
                else {
                    if (missing(files))
                        files <- FALSE
                    if (files == TRUE) {
                        ## Get file names
                        OSspec <- OSspec[rightType]
                        tmpMat <- matrix(nrow=nrow(mat),ncol=1)
                        for (i in 1:nrow(mat)) {
                            tmpMat[i,1] <-
                                basename(OSspec[[i]][type][[1]]$File)
                        }
                        mat <- cbind(mat, tmpMat)
                        colnames(mat)[3] <- "filenames"
                    }
                }
            }
            return(mat)
        }
        else return(NULL)
    })

    if (is.null(getGeneric("repPkgInfos")))
        setGeneric("repPkgInfos", function(object,pkgs,type)
                   standardGeneric("repPkgInfos"))
    setMethod("repPkgInfos", "ReposEntry", function(object,pkgs=NULL,type){
        if (missing(type))
            type <- NULL
        if (missing(pkgs))
            pkgs <- NULL

        ro <- repObjects(object,pkgs=pkgs,type=type)
        if (is.null(ro))
            return(ro)
        out <- list()
        if (nrow(ro) > 0) {
            for (i in 1:nrow(ro)) {
                out[[i]] <- buildPkgInfo(ro[i,"pkg"],ro[i,"vers"])
            }
        }
        return(out)
    })

    if (is.null(getGeneric("downloadFile")))
        setGeneric("downloadFile", function(object, file, vers, type,
                                            dest=NULL,method="auto")
                   standardGeneric("downloadFile"))
    setMethod("downloadFile", "ReposEntry", function(object, file,
                                                     vers, type,
                                                     dest=NULL,
                                                     method="auto") {

        if (missing(file)) {
            warning("Can not continue without a filename to download")
            return(NULL)
        }
        if (missing(type)) {
            warning("Can not continue without a 'type' to download")
            return(NULL)
        }
        if ((missing(vers)) && (type != "vignette")) {
            warning("Can not continue without a version of the file")
            return(NULL)
        }
        errMsg <- paste("There is no",type,"version of package",
                        file,"available at",repURL(object))
        ## Look up pkg/vers in DF
        rd <- repdataframe(object)

        print(paste("Attempting to download",file,"from",repURL(object)))

        if (repType(object) == "package") {
            rowName <- getMangledName(file,vers)
            ## try() doesn't seem to stop it from failing when
            ## indexing the rowname, so check first
            if (! rowName %in% rownames(rd))
                return(NULL)
            row <- rd[rowName,]
            ## get type
            osS <- row$OSspecific[[1]]
            if (is.null(osS))
                return(NULL)
            curOS <- which(names(osS) %in% type)
            if (length(curOS) > 0) {
                filePath <- osS[[curOS]]$File
                if (is.null(filePath)) {
                    warning(errMsg)
                    return(NULL)
                }
            }
            else {
                warning(errMsg)
                return(NULL)
            }
        }
        else if (repType(object) == "vignette") {
            vigRow <- which(rd$VignetteIndexEntry %in% vig)[1]
            filePath <- rd[vigRow,]$PDFpath
            if ((is.na(filePath))||(is.null(filePath))) {
                warning(paste("Vignette",file,"not found at",
                        repURL(object)))
                return(NULL)
            }
        }
        ## download to dest (NULL is temp)
        fileURL <- paste(repURL(object),filePath, sep="/")
        if (is.null(dest))
            dest <- tempdir()

        destFile <- file.path(dest,basename(filePath))
        download.file(fileURL, destFile, mode="wb", quiet=TRUE,
                      method=method)
        print("Download complete.")
        ## return filename (or NULL on error)
        return(destFile)
    })

    #########################
    #########################

    ############
    ## Display Methods
    ############
    setMethod("summary","ReposEntry",function(object, ...){
        cat("Repository Information:\n")
        summary(replisting(object))
        cat("\n")
        summary(repdatadesc(object))
    })
    setMethod("show","ReposEntry",function(object){
        cat("Repository Information:\n")
        show(replisting(object))
        cat("\n")
        show(repdatadesc(object))
    })
    #############

is.ReposEntry <- function(x) {
    if (class(x) == "ReposEntry")
        return(TRUE)
    else
        return(FALSE)
}

buildReposEntry <- function(replisting, repdatadesc) {
    a <- new("ReposEntry", replisting=replisting,
             repdatadesc=repdatadesc)
    if (is.null(a))
        warning("NULL ReposEntry object.  Check URL")
    return(a)
}


