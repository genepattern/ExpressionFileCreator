### Name: ReposEntry-class
### Title: A class to represent a repository
### Aliases: ReposEntry-class ReposEntry repdataframe repObjects
###   repPkgInfos repName repType repURL is.ReposEntry depends suggests
###   uses keywords numSubReps getSubRep getSubRepList hasFiles pkgRVersion
###   downloadFile depends,ReposEntry-method downloadFile,ReposEntry-method
###   getSubRep,ReposEntry-method getSubRepList,ReposEntry-method
###   hasFiles,ReposEntry-method keywords,ReposEntry-method
###   numSubReps,ReposEntry-method pkgRVersion,ReposEntry-method
###   repName,ReposEntry-method repObjects,ReposEntry-method
###   repPkgInfos,ReposEntry-method repPkgs,ReposEntry-method
###   repType,ReposEntry-method repURL,ReposEntry-method
###   repdatadesc,ReposEntry-method repdataframe,ReposEntry-method
###   replisting,ReposEntry-method show,ReposEntry-method
###   suggests,ReposEntry-method summary,ReposEntry-method
###   uses,ReposEntry-method
### Keywords: classes

### ** Examples

   ## TBD



