### Name: ReposList-class
### Title: Class "ReposList", a class to coordinate repository information
### Aliases: ReposList-class ReposList downloadRepFile getRepeEntry numReps
###   repList<- repList repNames repPkgInfoList repPkgs repURLs getRepEntry
###   downloadRepFile,ReposList-method getRepEntry,ReposList-method
###   numReps,ReposList-method repList,ReposList-method
###   repList<-,ReposList-method repNames,ReposList-method
###   repPkgInfoList,ReposList-method repPkgs,ReposList-method
###   repURLs,ReposList-method show,ReposList-method
### Keywords: classes

### ** Examples

##---- Should be DIRECTLY executable !! ----



