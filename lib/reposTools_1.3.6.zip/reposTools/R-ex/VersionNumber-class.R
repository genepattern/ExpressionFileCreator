### Name: VersionNumber-class
### Title: A class to handle version numbers
### Aliases: VersionNumber-class major minor stringRep revision
###   VersionNumber max.VersionNumber min.VersionNumber
###   !=,VersionNumber-method <,VersionNumber-method
###   <=,VersionNumber-method ==,VersionNumber-method
###   >,VersionNumber-method >=,VersionNumber-method
###   as.character,VersionNumber-method major,VersionNumber-method
###   minor,VersionNumber-method revision,VersionNumber-method
###   show,VersionNumber-method stringRep,VersionNumber-method
### Keywords: classes

### ** Examples

a <- buildVersionNumber("1.2.3")
major(a)
minor(a)
revision(a)
stringRep(a)



