### Name: buildPkgDepGraph
### Title: A function to build a package dependency graph
### Aliases: buildPkgDepGraph
### Keywords: utilities

### ** Examples

  if (require(graph)) {
    z <- buildPkgDepGraph("reposTools")
    if (interactive()) {
      ## If you have Rgraphviz package, can plot the graph
      if (require(Rgraphviz))
         plot(z)
    }
  }



