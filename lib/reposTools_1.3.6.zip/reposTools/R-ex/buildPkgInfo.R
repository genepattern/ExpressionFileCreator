### Name: buildPkgInfo
### Title: A constructor function for the pkgInfo class
### Aliases: buildPkgInfo
### Keywords: utilities

### ** Examples

a <- buildPkgInfo("foo","1.2.3")



