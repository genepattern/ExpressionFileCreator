### Name: buildReposEntry
### Title: A function to generate ReposEntry objects
### Aliases: buildReposEntry buildReposList
### Keywords: utilities

### ** Examples




