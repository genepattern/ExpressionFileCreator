### Name: buildVersionNumber
### Title: A function to generate a VersionNumber object
### Aliases: buildVersionNumber
### Keywords: utilities

### ** Examples

  a <- buildVersionNumber("1.2.3")



