### Name: buildVigDf
### Title: Functions to create repository data.frames
### Aliases: buildVigDf buildPkgDf addManifest addOsSpecific
### Keywords: utilities

### ** Examples




