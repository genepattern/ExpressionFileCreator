### Name: checkVers
### Title: A function to compare versions w/ operation string
### Aliases: checkVers
### Keywords: utilities

### ** Examples

   a <- buildVersionNumber("1.2.3")
   b <- buildVersionNumber("2.0")
   checkVers(a,"<=",b)    ## will see if a <= b
   checkVers(a,"==",b)
   checkVers(a,">",b)



