### Name: closeLocLib
### Title: A function to close a library listing
### Aliases: closeLocLib
### Keywords: utilities

### ** Examples

     lib <- paste(.find.package("reposTools"),"data/",sep="/")
     load.locLib(lib)
     closeLocLib()



