### Name: genRepos
### Title: A function to create a repository
### Aliases: genRepos genPkgRepos genVigRepos
### Keywords: utilities

### ** Examples




