### Name: getLocalPkgs
### Title: A function to list the locally installed packages
### Aliases: getLocalPkgs
### Keywords: utilities

### ** Examples

   getLocalPkgs()



