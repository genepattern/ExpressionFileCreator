### Name: getMaxVersion
### Title: A function to retrieve the maximum value from a list of
###   VersionNumbers
### Aliases: getMaxVersion getMaxElement getMinElement
### Keywords: utilities

### ** Examples

   a <- list(buildVersionNumber("1.2.3"), buildVersionNumber("1.5.0"))
   getMaxVersion(a)
   getMaxElement(a)



