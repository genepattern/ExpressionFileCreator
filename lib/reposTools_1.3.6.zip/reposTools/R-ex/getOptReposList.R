### Name: getOptReposList
### Title: A function to get a repository list from options
### Aliases: getOptReposList
### Keywords: utilities

### ** Examples

   getOptReposList()



