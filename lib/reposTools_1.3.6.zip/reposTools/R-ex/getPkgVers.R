### Name: getPkgVers
### Title: Information for an installed package
### Aliases: getPkgVers is.installed
### Keywords: utilities

### ** Examples

  lib <- paste(.find.package("reposTools"),"data/",sep="/")
  getPkgVers("reposTools",lib)



