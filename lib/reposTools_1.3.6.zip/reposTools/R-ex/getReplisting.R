### Name: getReplisting
### Title: A function to retrieve a repository replisting file
### Aliases: getReplisting
### Keywords: utilities

### ** Examples

  z <- getReplisting("http://www.bioconductor.org/repository/sample/package")
  z



