### Name: getReposEntry
### Title: A function to retrieve a ReposEntry object from a repository
### Aliases: getReposEntry
### Keywords: utilities

### ** Examples

  z <- getReposEntry("http://www.bioconductor.org/repository/sample/package")
  z



