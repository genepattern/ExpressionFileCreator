### Name: getReposList
### Title: A function to get a list of repository entries
### Aliases: getReposList
### Keywords: utilities

### ** Examples




