### Name: getReposOption
### Title: a function to find known repositories
### Aliases: getReposOption
### Keywords: utilities

### ** Examples

  z <- getReposOption
  z



