### Name: getRversion
### Title: A function to retrieve the current R version
### Aliases: getRversion
### Keywords: utilities

### ** Examples

getRversion()



