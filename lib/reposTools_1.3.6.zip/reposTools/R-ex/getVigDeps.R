### Name: getVigDeps
### Title: A function to extract dependencies
### Aliases: getVigDeps getPkgDeps getObjectDeps
### Keywords: utilities

### ** Examples

   getPkgDeps("affy")



