### Name: install.packages2
### Title: Functions to download, install and manipulate local packages
### Aliases: install.packages2 remove.packages2 download.packages2
###   update.packages2 checkPrevRepos baseFileSelect handleDownloadedFile
###   installPkg
### Keywords: utilities

### ** Examples

## set up a temporary directory for use with these examples
## this directory will be used with the this-is-escaped-code{
## parameter.  For normal usage, most users will be okay with using
## the defaults of this-is-escaped-codenormal-bracket69bracket-normal and not need to specify manually
tmpLib <- tempfile()
dir.create(tmpLib)

## install a package from the standard repositories (listed by
## the command this-is-escaped-codenormal-bracket70bracket-normal
install.packages2("hu6800",lib=tmpLib)
## and another one from CRAN
install.packages2("abind",lib=tmpLib)



