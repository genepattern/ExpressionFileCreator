### Name: load.depends
### Title: A function to load package/vignette dependencies
### Aliases: load.depends unresolved.depends checkRVersion check.depends
### Keywords: utilities

### ** Examples

   load.depends("Biobase")



