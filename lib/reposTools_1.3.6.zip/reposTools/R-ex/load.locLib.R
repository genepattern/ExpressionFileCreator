### Name: load.locLib
### Title: A function to load a local library listing
### Aliases: load.locLib
### Keywords: utilities

### ** Examples

   lib <- paste(.find.package("reposTools"),"data/",sep="/")
   load.locLib(lib)



