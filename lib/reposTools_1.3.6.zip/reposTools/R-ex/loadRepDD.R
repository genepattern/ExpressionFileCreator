### Name: loadRepDD
### Title: A function to retreive a repository data frame
### Aliases: loadRepDD
### Keywords: utilities

### ** Examples

   rDf <- loadRepDD("http://www.bioconductor.org/repository/sample/package")



