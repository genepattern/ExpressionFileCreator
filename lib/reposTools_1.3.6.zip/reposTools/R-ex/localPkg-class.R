### Name: localPkg-class
### Title: Class "localPkg": A class to represent locally installed
###   packages
### Aliases: localPkg-class Depends Keywords Package Repos Suggests Uses
###   PkgVersion Depends,localPkg-method Keywords,localPkg-method
###   Package,localPkg-method PkgVersion,localPkg-method
###   Repos,localPkg-method Suggests,localPkg-method Uses,localPkg-method
### Keywords: classes

### ** Examples




