### Name: note
### Title: Informational Messages
### Aliases: note
### Keywords: utilities

### ** Examples

   note("This is an example of a note")



