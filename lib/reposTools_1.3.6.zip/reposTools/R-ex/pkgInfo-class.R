### Name: pkgInfo-class
### Title: A class to hold package information
### Aliases: pkgInfo-class pkgName pkgVersion pkgPath pkgInfo
###   ==,pkgInfo-method pkgName,pkgInfo-method pkgPath,pkgInfo-method
###   pkgVersion,pkgInfo-method show,pkgInfo-method
### Keywords: classes

### ** Examples

 a <- buildPkgInfo("Foo","1.2.3")



