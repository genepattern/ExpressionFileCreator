### Name: pkgListing-class
### Title: A class to coordinate repository package information
### Aliases: pkgListing-class pkgListing packages pkgList repListing
###   pkgNames pkgVersionList downloadRepFile,pkgListing-method
###   getRepEntry,pkgListing-method packages,pkgListing-method
###   pkgList,pkgListing-method pkgVersionList,pkgListing-method
###   repList,pkgListing-method repListing,pkgListing-method
###   show,pkgListing-method summary,pkgListing-method
### Keywords: classes

### ** Examples

##---- Should be DIRECTLY executable !! ----



