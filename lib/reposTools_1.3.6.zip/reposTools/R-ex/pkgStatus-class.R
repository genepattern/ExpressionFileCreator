### Name: pkgStatus-class
### Title: Class "pkgStatus", maintains download status of a package
### Aliases: pkgStatus-class pkgStatus package found updated URL
###   URL,pkgStatus-method found,pkgStatus-method package,pkgStatus-method
###   pkgVersion,pkgStatus-method show,pkgStatus-method
###   updated,pkgStatus-method
### Keywords: classes

### ** Examples

##---- Should be DIRECTLY executable !! ----



