### Name: pkgStatusList-class
### Title: Class "pkgStatusList", maintains status for multiple packages
### Aliases: pkgStatusList-class pkgStatusList statusList statusList<-
###   notFound notUpdated urls pkgVersions foundPkgs notFoundPkgs
###   updatedPkgs getPackage getFound getUpdated getUrl getPkgVersion
###   foundPkgs,pkgStatusList-method found,pkgStatusList-method
###   getFound,pkgStatusList-method getPackage,pkgStatusList-method
###   getPkgVersion,pkgStatusList-method getUpdated,pkgStatusList-method
###   getUrl,pkgStatusList-method notFoundPkgs,pkgStatusList-method
###   notFound,pkgStatusList-method notUpdated,pkgStatusList-method
###   packages,pkgStatusList-method pkgVersions,pkgStatusList-method
###   show,pkgStatusList-method statusList<-,pkgStatusList-method
###   statusList,pkgStatusList-method updatedPkgs,pkgStatusList-method
###   updated,pkgStatusList-method urls,pkgStatusList-method
### Keywords: classes

### ** Examples

##---- Should be DIRECTLY executable !! ----



