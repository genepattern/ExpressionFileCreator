### Name: repdatadesc-class
### Title: A class to represent a repository data frame
### Aliases: repdatadesc-class repdatadesc depends,repdatadesc-method
###   keywords,repdatadesc-method repdatadesc,repdatadesc-method
###   show,repdatadesc-method suggests,repdatadesc-method
###   summary,repdatadesc-method uses,repdatadesc-method
### Keywords: classes

### ** Examples

data(sampleRepos)
a <- new("repdatadesc",repdatadesc=reposDF)
a



