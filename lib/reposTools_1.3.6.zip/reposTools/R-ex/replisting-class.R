### Name: replisting-class
### Title: A class to represent repository information
### Aliases: replisting-class replisting numSubReps,replisting-method
###   replisting,replisting-method repURL,replisting-method
###   show,replisting-method summary,replisting-method
### Keywords: classes

### ** Examples

## Note that generally the replisting matrix would come from a
## repository 'replisting' file.  Generating it manually here.
a <- matrix(ncol=4,nrow=1)
a[1,] <- c("Test Repository",
  "package","http://www.bioconductor.org/repository","/sample/package")

colnames(a) <- c("repname","reptype","repaddrBase","repaddrPath")

z <- new("replisting",replisting=a)
z



