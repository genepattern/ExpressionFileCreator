### Name: reposToolsLibPaths
### Title: A function to handle temporary libPaths
### Aliases: reposToolsLibPaths
### Keywords: utilities

### ** Examples

  z <- reposToolsLibPaths()



