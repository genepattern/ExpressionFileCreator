### Name: repositories
### Title: A function to choose a repository
### Aliases: repositories
### Keywords: utilities

### ** Examples

  if (interactive()) {
    z <- repositories()
    z
 }



