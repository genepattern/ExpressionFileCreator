### Name: resolve.depends
### Title: A function to check for dependency breakages
### Aliases: resolve.depends findInstallDepends solveForwardDepends
### Keywords: utilities

### ** Examples




