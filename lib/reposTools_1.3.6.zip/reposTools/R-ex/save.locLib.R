### Name: save.locLib
### Title: A function to save a local lib listing
### Aliases: save.locLib
### Keywords: utilities

### ** Examples

   lib <- paste(.find.package("reposTools"),"data/",sep="/")
   load.locLib(lib)
   save.locLib(locLibList,lib)



