### Name: splitDFstrings
### Title: A function to split vector strings in a data.frame
### Aliases: splitDFstrings
### Keywords: utilities

### ** Examples

   a <- data.frame(I("foo, blah"))
   colnames(a) <- "bar"
   a
   splitDFstrings(a,"bar")
   a$bar



