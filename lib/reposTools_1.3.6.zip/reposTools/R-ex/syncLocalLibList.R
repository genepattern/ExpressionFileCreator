### Name: syncLocalLibList
### Title: A function to synch the local library file
### Aliases: syncLocalLibList
### Keywords: utilities

### ** Examples

    ## make a temporary directory for use in this example
    a <- tempfile()
    dir.create(a)
    syncLocalLibList(a)
    unlink(a,recursive=TRUE)



