### Name: unpackExtractPkgDESC
### Title: Functions to unpack built packages
### Aliases: unpackExtractPkgDESC unpackSourcePkg unpackZipPkg
### Keywords: utilities

### ** Examples




