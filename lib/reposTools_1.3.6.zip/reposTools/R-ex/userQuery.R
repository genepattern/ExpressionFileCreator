### Name: userQuery
### Title: A function to query the user for input
### Aliases: userQuery
### Keywords: utilities

### ** Examples




