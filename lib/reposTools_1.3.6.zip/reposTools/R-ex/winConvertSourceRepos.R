### Name: winConvertSourceRepos
### Title: A function to convert source repositories to Win32 repositories
### Aliases: winConvertSourceRepos
### Keywords: utilities

### ** Examples




