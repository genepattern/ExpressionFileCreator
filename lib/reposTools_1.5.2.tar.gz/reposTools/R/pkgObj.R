    setClass("localPkg", representation(Package="character",
                                        PkgVersion="VersionNumber",
                                        Keywords="character",
                                        Depends="character",
                                        Suggests="character",
                                        Imports="character",
                                        Repos="character",
                                        Bundle="character"))


if (is.null(getGeneric("Package")))
    setGeneric("Package", function(object, ...)
               standardGeneric("Package"))
setMethod("Package", "localPkg", function(object, ...)
          object@Package)

if (is.null(getGeneric("PkgVersion")))
    setGeneric("PkgVersion", function(object, ...)
               standardGeneric("PkgVersion"))
setMethod("PkgVersion", "localPkg", function(object, ...)
          object@PkgVersion)

if (is.null(getGeneric("Keywords")))
    setGeneric("Keywords", function(object, ...)
               standardGeneric("Keywords"))
setMethod("Keywords", "localPkg", function(object, ...)
          object@Keywords)

if (is.null(getGeneric("Depends")))
    setGeneric("Depends", function(object, ...)
               standardGeneric("Depends"))
setMethod("Depends", "localPkg", function(object, ...)
          object@Depends)


if (is.null(getGeneric("Suggests")))
    setGeneric("Suggests", function(object, ...)
               standardGeneric("Suggests"))
setMethod("Suggests", "localPkg", function(object, ...)
          object@Suggests)

if (is.null(getGeneric("Imports")))
    setGeneric("Imports", function(object, ...)
               standardGeneric("Imports"))
setMethod("Imports", "localPkg", function(object, ...)
          object@Imports)

if (is.null(getGeneric("Repos")))
    setGeneric("Repos", function(object, ...)
               standardGeneric("Repos"))
setMethod("Repos", "localPkg", function(object, ...)
          object@Repos)

if (is.null(getGeneric("Bundle")))
    setGeneric("Bundle", function(object, ...)
               standardGeneric("Bundle"))
setMethod("Bundle", "localPkg", function(object, ...)
          object@Bundle)
